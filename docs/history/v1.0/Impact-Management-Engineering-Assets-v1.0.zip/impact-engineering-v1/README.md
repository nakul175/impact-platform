# Impact Management Platform Engineering Assets

Version 1.0 • 24 September 2026

This archive accompanies the test catalogue, 30-screen wireframe prototype, HLD, LLD and test strategy. It is a proposed engineering design, not an implemented platform. The source is Impact Management Platform FSD v1.0, SHA256 `1dccf4fbe6361c5530aef5239a880d87bf440eb5a548d31a8c32ad559b10e66a`.

## Contents

- `docs/`: editable architecture and testing text, diagrams, fixture contract and qualification gaps.
- `contracts/openapi.json`: proposed OpenAPI 3.1.1 routes and DTO envelopes.
- `contracts/entity-catalogue.json`: 37 FSD entities and 12 supporting API entities.
- `contracts/postgresql-blueprint.sql`: PostgreSQL 17 storage/RLS design; not an applied migration.
- `fixtures/vectors.json`: 140 fixed calculation/control examples.
- `fixtures/test-catalogue.json`: all workbook case details and traceability data.
- `fixtures/api-fixture.example.json`: placeholder IDs and credential environment-variable names.
- `reference_core.py`: executable design reference for selected pure contracts.
- `tests/`: 143 unit reference tests, 18 API integration cases and 12 readonly smoke cases.
- `reports/`: actual preparation execution results, with product validation explicitly false.
- `wireframes.html`: standalone prototype with synthetic in-memory interactions.

## Run the reference suite

Use Python 3.11 or newer. The tests use the Python standard library and need no third-party package installation.

```bash
python3 run_tests.py reference --report reports/reference-execution.json
```

The recorded preparation run passed 143 tests. This validates the included reference functions only. It does not establish security, data durability, database behaviour, full CAL01–CAL20 coverage, performance or the product's branch coverage.

## Run against an implementation

Provision the isolated fixture in `docs/fixture-contract.md`. Copy the example fixture to a private local path and replace every identifier with real synthetic fixture IDs. Set `IMPACT_BASE_URL`, `IMPACT_FIXTURE_FILE` and each token environment variable named in the fixture. Do not commit tokens or personal data.

```bash
python3 run_tests.py integration --report reports/integration-execution.json
python3 run_tests.py smoke --report reports/smoke-execution.json
```

Integration cases 13–18 may issue mutations. They require `IMPACT_ALLOW_MUTATIONS=1`, fixture `allow_mutations: true`, and a matching runtime manifest explicitly allowing mutation tests in development, test or staging. The script refuses a production mutation environment. Two tests restore the original title through a new audited revision; they do not delete history.

Exit codes: 0 means all requested assertions executed and passed; 1 means failure; 3 means blocked/skipped required execution. Do not configure CI to treat exit 3 as a successful release gate. The included API reports are Blocked because no implementation URL or provisioned fixture was available.

## Open the wireframes

Open `wireframes.html` in a browser. Navigation exposes all UI01–UI30 designs. Choose a design role and screen state to inspect the flow. A sample sequence is UI13 Save on device → UI14 Sync now → UI21 select Riya and approve → UI24 load the complete-period example and close → UI23 approve and publish the report.

The complete-period control loads a different synthetic fixture. A real product cannot satisfy missing obligations through a button that merely changes counts. The prototype does not implement authentication, server persistence or real disclosure. It makes no network requests and retains simulation state only in memory.

## Qualification before implementation release

Close nested write DTOs, produce concrete FK/privilege migrations, implement the remaining domain/adapters and qualify against real infrastructure. The archived SQL must not be applied directly to production. Read the detailed LLD and `docs/qualification-gaps.md` before baselining implementation contracts. Required security, privacy, NFR, device, accessibility and provider tests remain unrun.
