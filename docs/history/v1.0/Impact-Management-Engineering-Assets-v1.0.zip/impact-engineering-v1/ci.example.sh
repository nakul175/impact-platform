#!/usr/bin/env bash
# Reference CI template. Run from the extracted archive root.
# Any Blocked exit (3) fails a required stage. Do not append "|| true".
set -euo pipefail
python3 run_tests.py reference --report reports/reference-execution.json
python3 run_tests.py integration --report reports/integration-execution.json
python3 run_tests.py smoke --report reports/smoke-execution.json
