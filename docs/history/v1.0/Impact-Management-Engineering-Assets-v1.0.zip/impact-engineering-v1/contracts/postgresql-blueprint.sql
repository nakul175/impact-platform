-- PostgreSQL 17 compatibility blueprint. Qualify against real PostgreSQL before migration use.

-- Runtime role must be non-owner NOBYPASSRLS, without CREATE, TRUNCATE or direct partition privileges.

-- Deployment owns roles and least-privilege GRANT statements. Do not connect as table owner.

CREATE SCHEMA IF NOT EXISTS impact;

CREATE TABLE impact.tenant_root (tenant_id uuid PRIMARY KEY, region_policy text NOT NULL, lifecycle_state text NOT NULL);

CREATE TABLE impact.auth_identity (identity_id uuid PRIMARY KEY, issuer text NOT NULL, provider_subject text NOT NULL, natural_identity_id uuid NOT NULL, UNIQUE(issuer,provider_subject));

CREATE TABLE impact.object_registry (
tenant_id uuid NOT NULL REFERENCES impact.tenant_root, object_id uuid NOT NULL, object_type text NOT NULL,
head_revision uuid NOT NULL, lifecycle_state text NOT NULL, classification text NOT NULL, owner_id uuid,
created_at timestamptz NOT NULL, created_by uuid NOT NULL, updated_at timestamptz NOT NULL,
PRIMARY KEY(tenant_id,object_id));

CREATE TABLE impact.object_revision (
tenant_id uuid NOT NULL, object_id uuid NOT NULL, revision_id uuid NOT NULL, predecessor_revision uuid,
schema_version text NOT NULL, payload jsonb, payload_sha256 bytea NOT NULL CHECK(octet_length(payload_sha256)=32),
author_id uuid NOT NULL, created_at timestamptz NOT NULL, restriction_state text NOT NULL DEFAULT 'AVAILABLE',
PRIMARY KEY(tenant_id,object_id,revision_id), UNIQUE(tenant_id,revision_id),
FOREIGN KEY(tenant_id,object_id) REFERENCES impact.object_registry DEFERRABLE INITIALLY DEFERRED,
FOREIGN KEY(tenant_id,object_id,predecessor_revision) REFERENCES impact.object_revision DEFERRABLE INITIALLY DEFERRED);
ALTER TABLE impact.object_registry ADD CONSTRAINT registry_head FOREIGN KEY(tenant_id,object_id,head_revision) REFERENCES impact.object_revision(tenant_id,object_id,revision_id) DEFERRABLE INITIALLY DEFERRED;

CREATE TABLE impact.tenant_current (
tenant_id uuid NOT NULL,
object_id uuid NOT NULL,
revision_id uuid NOT NULL,
operating_name varchar(200),
owner_membership_id uuid,
reporting_zone text,
hosting_policy_id uuid,
privacy_policy_id uuid,
retention_policy_id uuid,
PRIMARY KEY(tenant_id,object_id),
FOREIGN KEY(tenant_id,object_id,revision_id) REFERENCES impact.object_revision(tenant_id,object_id,revision_id) DEFERRABLE INITIALLY DEFERRED
);

-- tenant_current.owner_membership_id: classify as identity, object or immutable revision FK in typed migration; cross-tenant references must be rejected.

-- tenant_current.hosting_policy_id: classify as identity, object or immutable revision FK in typed migration; cross-tenant references must be rejected.

-- tenant_current.privacy_policy_id: classify as identity, object or immutable revision FK in typed migration; cross-tenant references must be rejected.

-- tenant_current.retention_policy_id: classify as identity, object or immutable revision FK in typed migration; cross-tenant references must be rejected.

CREATE TABLE impact.membership_current (
tenant_id uuid NOT NULL,
object_id uuid NOT NULL,
revision_id uuid NOT NULL,
identity_id uuid,
authority_source text,
external boolean,
expires_at timestamptz,
PRIMARY KEY(tenant_id,object_id),
FOREIGN KEY(tenant_id,object_id,revision_id) REFERENCES impact.object_revision(tenant_id,object_id,revision_id) DEFERRABLE INITIALLY DEFERRED
);

-- membership_current.identity_id: classify as identity, object or immutable revision FK in typed migration; cross-tenant references must be rejected.

CREATE TABLE impact.grant_current (
tenant_id uuid NOT NULL,
object_id uuid NOT NULL,
revision_id uuid NOT NULL,
subject_id uuid,
capability varchar(64),
scope_id uuid,
starts_at timestamptz,
expires_at timestamptz,
purpose varchar(64),
PRIMARY KEY(tenant_id,object_id),
FOREIGN KEY(tenant_id,object_id,revision_id) REFERENCES impact.object_revision(tenant_id,object_id,revision_id) DEFERRABLE INITIALLY DEFERRED
);

-- grant_current.subject_id: classify as identity, object or immutable revision FK in typed migration; cross-tenant references must be rejected.

-- grant_current.scope_id: classify as identity, object or immutable revision FK in typed migration; cross-tenant references must be rejected.

CREATE TABLE impact.organisation_unit_current (
tenant_id uuid NOT NULL,
object_id uuid NOT NULL,
revision_id uuid NOT NULL,
code varchar(64),
name varchar(200),
parent_id uuid,
PRIMARY KEY(tenant_id,object_id),
FOREIGN KEY(tenant_id,object_id,revision_id) REFERENCES impact.object_revision(tenant_id,object_id,revision_id) DEFERRABLE INITIALLY DEFERRED
);

-- organisation_unit_current.parent_id: classify as identity, object or immutable revision FK in typed migration; cross-tenant references must be rejected.

CREATE TABLE impact.programme_current (
tenant_id uuid NOT NULL,
object_id uuid NOT NULL,
revision_id uuid NOT NULL,
code varchar(64),
title varchar(200),
programme_type varchar(64),
starts_at timestamptz,
ends_at timestamptz,
reporting_calendar_id uuid,
geography_id uuid,
PRIMARY KEY(tenant_id,object_id),
FOREIGN KEY(tenant_id,object_id,revision_id) REFERENCES impact.object_revision(tenant_id,object_id,revision_id) DEFERRABLE INITIALLY DEFERRED
);

-- programme_current.reporting_calendar_id: classify as identity, object or immutable revision FK in typed migration; cross-tenant references must be rejected.

-- programme_current.geography_id: classify as identity, object or immutable revision FK in typed migration; cross-tenant references must be rejected.

CREATE TABLE impact.framework_current (
tenant_id uuid NOT NULL,
object_id uuid NOT NULL,
revision_id uuid NOT NULL,
programme_id uuid,
version_label varchar(64),
nodes jsonb,
relationships jsonb,
PRIMARY KEY(tenant_id,object_id),
FOREIGN KEY(tenant_id,object_id,revision_id) REFERENCES impact.object_revision(tenant_id,object_id,revision_id) DEFERRABLE INITIALLY DEFERRED
);

-- framework_current.programme_id: classify as identity, object or immutable revision FK in typed migration; cross-tenant references must be rejected.

CREATE TABLE impact.indicator_definition_current (
tenant_id uuid NOT NULL,
object_id uuid NOT NULL,
revision_id uuid NOT NULL,
code varchar(64),
name varchar(200),
measurement_type varchar(64),
unit varchar(64),
population text,
inclusion text,
exclusion text,
method text,
source_mode varchar(64),
time_semantic varchar(64),
combination_rule varchar(64),
display_decimals integer,
PRIMARY KEY(tenant_id,object_id),
FOREIGN KEY(tenant_id,object_id,revision_id) REFERENCES impact.object_revision(tenant_id,object_id,revision_id) DEFERRABLE INITIALLY DEFERRED
);

CREATE TABLE impact.indicator_instance_current (
tenant_id uuid NOT NULL,
object_id uuid NOT NULL,
revision_id uuid NOT NULL,
definition_version uuid,
programme_id uuid,
local_applicability text,
collector_id uuid,
reviewer_id uuid,
schedule_id uuid,
PRIMARY KEY(tenant_id,object_id),
FOREIGN KEY(tenant_id,object_id,revision_id) REFERENCES impact.object_revision(tenant_id,object_id,revision_id) DEFERRABLE INITIALLY DEFERRED
);

-- indicator_instance_current.definition_version: classify as identity, object or immutable revision FK in typed migration; cross-tenant references must be rejected.

-- indicator_instance_current.programme_id: classify as identity, object or immutable revision FK in typed migration; cross-tenant references must be rejected.

-- indicator_instance_current.collector_id: classify as identity, object or immutable revision FK in typed migration; cross-tenant references must be rejected.

-- indicator_instance_current.reviewer_id: classify as identity, object or immutable revision FK in typed migration; cross-tenant references must be rejected.

-- indicator_instance_current.schedule_id: classify as identity, object or immutable revision FK in typed migration; cross-tenant references must be rejected.

CREATE TABLE impact.target_current (
tenant_id uuid NOT NULL,
object_id uuid NOT NULL,
revision_id uuid NOT NULL,
indicator_version uuid,
period_id uuid,
target_kind varchar(64),
value_state varchar(32),
value numeric(38,12),
low numeric(38,12),
high numeric(38,12),
direction varchar(64),
target_basis varchar(64),
PRIMARY KEY(tenant_id,object_id),
FOREIGN KEY(tenant_id,object_id,revision_id) REFERENCES impact.object_revision(tenant_id,object_id,revision_id) DEFERRABLE INITIALLY DEFERRED
);

-- target_current.indicator_version: classify as identity, object or immutable revision FK in typed migration; cross-tenant references must be rejected.

-- target_current.period_id: classify as identity, object or immutable revision FK in typed migration; cross-tenant references must be rejected.

CREATE TABLE impact.dimension_current (
tenant_id uuid NOT NULL,
object_id uuid NOT NULL,
revision_id uuid NOT NULL,
code varchar(64),
label varchar(200),
categories jsonb,
mutually_exclusive boolean,
exhaustive boolean,
effective_at timestamptz,
PRIMARY KEY(tenant_id,object_id),
FOREIGN KEY(tenant_id,object_id,revision_id) REFERENCES impact.object_revision(tenant_id,object_id,revision_id) DEFERRABLE INITIALLY DEFERRED
);

CREATE TABLE impact.period_current (
tenant_id uuid NOT NULL,
object_id uuid NOT NULL,
revision_id uuid NOT NULL,
calendar_version uuid,
code varchar(64),
starts_at timestamptz,
ends_at timestamptz,
reporting_zone text,
PRIMARY KEY(tenant_id,object_id),
FOREIGN KEY(tenant_id,object_id,revision_id) REFERENCES impact.object_revision(tenant_id,object_id,revision_id) DEFERRABLE INITIALLY DEFERRED,
CHECK (starts_at < ends_at)
);

-- period_current.calendar_version: classify as identity, object or immutable revision FK in typed migration; cross-tenant references must be rejected.

CREATE TABLE impact.observation_current (
tenant_id uuid NOT NULL,
object_id uuid NOT NULL,
revision_id uuid NOT NULL,
source_namespace varchar(64),
source_key text,
indicator_id uuid,
dataset_id uuid,
event_at timestamptz,
captured_at timestamptz,
capture_zone text,
value_state varchar(32),
value numeric(38,12),
numerator numeric(38,12),
denominator numeric(38,12),
source_version text,
dimension_values jsonb,
PRIMARY KEY(tenant_id,object_id),
FOREIGN KEY(tenant_id,object_id,revision_id) REFERENCES impact.object_revision(tenant_id,object_id,revision_id) DEFERRABLE INITIALLY DEFERRED,
CHECK (value_state IS NOT NULL AND value_state IN ('PRESENT','MISSING','NOT_COLLECTED','NOT_APPLICABLE','INVALID','UNDEFINED')),
CHECK ((value_state='PRESENT' AND value IS NOT NULL) OR (value_state<>'PRESENT' AND value IS NULL))
) PARTITION BY HASH (tenant_id);

CREATE TABLE impact.observation_p00 PARTITION OF impact.observation_current FOR VALUES WITH (MODULUS 32, REMAINDER 0);

CREATE TABLE impact.observation_p01 PARTITION OF impact.observation_current FOR VALUES WITH (MODULUS 32, REMAINDER 1);

CREATE TABLE impact.observation_p02 PARTITION OF impact.observation_current FOR VALUES WITH (MODULUS 32, REMAINDER 2);

CREATE TABLE impact.observation_p03 PARTITION OF impact.observation_current FOR VALUES WITH (MODULUS 32, REMAINDER 3);

CREATE TABLE impact.observation_p04 PARTITION OF impact.observation_current FOR VALUES WITH (MODULUS 32, REMAINDER 4);

CREATE TABLE impact.observation_p05 PARTITION OF impact.observation_current FOR VALUES WITH (MODULUS 32, REMAINDER 5);

CREATE TABLE impact.observation_p06 PARTITION OF impact.observation_current FOR VALUES WITH (MODULUS 32, REMAINDER 6);

CREATE TABLE impact.observation_p07 PARTITION OF impact.observation_current FOR VALUES WITH (MODULUS 32, REMAINDER 7);

CREATE TABLE impact.observation_p08 PARTITION OF impact.observation_current FOR VALUES WITH (MODULUS 32, REMAINDER 8);

CREATE TABLE impact.observation_p09 PARTITION OF impact.observation_current FOR VALUES WITH (MODULUS 32, REMAINDER 9);

CREATE TABLE impact.observation_p10 PARTITION OF impact.observation_current FOR VALUES WITH (MODULUS 32, REMAINDER 10);

CREATE TABLE impact.observation_p11 PARTITION OF impact.observation_current FOR VALUES WITH (MODULUS 32, REMAINDER 11);

CREATE TABLE impact.observation_p12 PARTITION OF impact.observation_current FOR VALUES WITH (MODULUS 32, REMAINDER 12);

CREATE TABLE impact.observation_p13 PARTITION OF impact.observation_current FOR VALUES WITH (MODULUS 32, REMAINDER 13);

CREATE TABLE impact.observation_p14 PARTITION OF impact.observation_current FOR VALUES WITH (MODULUS 32, REMAINDER 14);

CREATE TABLE impact.observation_p15 PARTITION OF impact.observation_current FOR VALUES WITH (MODULUS 32, REMAINDER 15);

CREATE TABLE impact.observation_p16 PARTITION OF impact.observation_current FOR VALUES WITH (MODULUS 32, REMAINDER 16);

CREATE TABLE impact.observation_p17 PARTITION OF impact.observation_current FOR VALUES WITH (MODULUS 32, REMAINDER 17);

CREATE TABLE impact.observation_p18 PARTITION OF impact.observation_current FOR VALUES WITH (MODULUS 32, REMAINDER 18);

CREATE TABLE impact.observation_p19 PARTITION OF impact.observation_current FOR VALUES WITH (MODULUS 32, REMAINDER 19);

CREATE TABLE impact.observation_p20 PARTITION OF impact.observation_current FOR VALUES WITH (MODULUS 32, REMAINDER 20);

CREATE TABLE impact.observation_p21 PARTITION OF impact.observation_current FOR VALUES WITH (MODULUS 32, REMAINDER 21);

CREATE TABLE impact.observation_p22 PARTITION OF impact.observation_current FOR VALUES WITH (MODULUS 32, REMAINDER 22);

CREATE TABLE impact.observation_p23 PARTITION OF impact.observation_current FOR VALUES WITH (MODULUS 32, REMAINDER 23);

CREATE TABLE impact.observation_p24 PARTITION OF impact.observation_current FOR VALUES WITH (MODULUS 32, REMAINDER 24);

CREATE TABLE impact.observation_p25 PARTITION OF impact.observation_current FOR VALUES WITH (MODULUS 32, REMAINDER 25);

CREATE TABLE impact.observation_p26 PARTITION OF impact.observation_current FOR VALUES WITH (MODULUS 32, REMAINDER 26);

CREATE TABLE impact.observation_p27 PARTITION OF impact.observation_current FOR VALUES WITH (MODULUS 32, REMAINDER 27);

CREATE TABLE impact.observation_p28 PARTITION OF impact.observation_current FOR VALUES WITH (MODULUS 32, REMAINDER 28);

CREATE TABLE impact.observation_p29 PARTITION OF impact.observation_current FOR VALUES WITH (MODULUS 32, REMAINDER 29);

CREATE TABLE impact.observation_p30 PARTITION OF impact.observation_current FOR VALUES WITH (MODULUS 32, REMAINDER 30);

CREATE TABLE impact.observation_p31 PARTITION OF impact.observation_current FOR VALUES WITH (MODULUS 32, REMAINDER 31);

-- observation_current.indicator_id: classify as identity, object or immutable revision FK in typed migration; cross-tenant references must be rejected.

-- observation_current.dataset_id: classify as identity, object or immutable revision FK in typed migration; cross-tenant references must be rejected.

CREATE TABLE impact.calculated_result_current (
tenant_id uuid NOT NULL,
object_id uuid NOT NULL,
revision_id uuid NOT NULL,
indicator_version uuid,
period_id uuid,
dimensions jsonb,
rule_version uuid,
input_snapshot_id uuid,
run_id uuid,
value_state varchar(32),
value numeric(38,12),
numerator numeric(38,12),
denominator numeric(38,12),
unit varchar(64),
displayed_value text,
display_decimals integer,
rounding_rule varchar(64),
mode varchar(64),
coverage jsonb,
freshness jsonb,
limitations jsonb,
reason_code varchar(64),
lineage_manifest_id uuid,
PRIMARY KEY(tenant_id,object_id),
FOREIGN KEY(tenant_id,object_id,revision_id) REFERENCES impact.object_revision(tenant_id,object_id,revision_id) DEFERRABLE INITIALLY DEFERRED
);

-- calculated_result_current.indicator_version: classify as identity, object or immutable revision FK in typed migration; cross-tenant references must be rejected.

-- calculated_result_current.period_id: classify as identity, object or immutable revision FK in typed migration; cross-tenant references must be rejected.

-- calculated_result_current.rule_version: classify as identity, object or immutable revision FK in typed migration; cross-tenant references must be rejected.

-- calculated_result_current.input_snapshot_id: classify as identity, object or immutable revision FK in typed migration; cross-tenant references must be rejected.

-- calculated_result_current.lineage_manifest_id: classify as identity, object or immutable revision FK in typed migration; cross-tenant references must be rejected.

CREATE TABLE impact.form_current (
tenant_id uuid NOT NULL,
object_id uuid NOT NULL,
revision_id uuid NOT NULL,
code varchar(64),
title varchar(200),
fields jsonb,
logic jsonb,
translation_versions jsonb,
compatibility_policy varchar(64),
PRIMARY KEY(tenant_id,object_id),
FOREIGN KEY(tenant_id,object_id,revision_id) REFERENCES impact.object_revision(tenant_id,object_id,revision_id) DEFERRABLE INITIALLY DEFERRED
);

CREATE TABLE impact.form_field_current (
tenant_id uuid NOT NULL,
object_id uuid NOT NULL,
revision_id uuid NOT NULL,
form_id uuid,
stable_code varchar(64),
field_type varchar(64),
label varchar(200),
required_expression text,
relevance_expression text,
validation_expression text,
calculation_expression text,
choices jsonb,
parent_field_id uuid,
hidden_value_policy varchar(64),
PRIMARY KEY(tenant_id,object_id),
FOREIGN KEY(tenant_id,object_id,revision_id) REFERENCES impact.object_revision(tenant_id,object_id,revision_id) DEFERRABLE INITIALLY DEFERRED
);

-- form_field_current.form_id: classify as identity, object or immutable revision FK in typed migration; cross-tenant references must be rejected.

-- form_field_current.parent_field_id: classify as identity, object or immutable revision FK in typed migration; cross-tenant references must be rejected.

CREATE TABLE impact.assignment_current (
tenant_id uuid NOT NULL,
object_id uuid NOT NULL,
revision_id uuid NOT NULL,
round_id uuid,
form_version uuid,
assignee_id uuid,
scope_id uuid,
due_at timestamptz,
PRIMARY KEY(tenant_id,object_id),
FOREIGN KEY(tenant_id,object_id,revision_id) REFERENCES impact.object_revision(tenant_id,object_id,revision_id) DEFERRABLE INITIALLY DEFERRED
);

-- assignment_current.round_id: classify as identity, object or immutable revision FK in typed migration; cross-tenant references must be rejected.

-- assignment_current.form_version: classify as identity, object or immutable revision FK in typed migration; cross-tenant references must be rejected.

-- assignment_current.assignee_id: classify as identity, object or immutable revision FK in typed migration; cross-tenant references must be rejected.

-- assignment_current.scope_id: classify as identity, object or immutable revision FK in typed migration; cross-tenant references must be rejected.

CREATE TABLE impact.submission_current (
tenant_id uuid NOT NULL,
object_id uuid NOT NULL,
revision_id uuid NOT NULL,
submission_id uuid,
form_version uuid,
assignment_id uuid,
respondent_scope_id uuid,
event_at timestamptz,
captured_at timestamptz,
capture_zone text,
answers jsonb,
attachments jsonb,
offline_grant_id uuid,
PRIMARY KEY(tenant_id,object_id),
FOREIGN KEY(tenant_id,object_id,revision_id) REFERENCES impact.object_revision(tenant_id,object_id,revision_id) DEFERRABLE INITIALLY DEFERRED
);

-- submission_current.form_version: classify as identity, object or immutable revision FK in typed migration; cross-tenant references must be rejected.

-- submission_current.assignment_id: classify as identity, object or immutable revision FK in typed migration; cross-tenant references must be rejected.

-- submission_current.respondent_scope_id: classify as identity, object or immutable revision FK in typed migration; cross-tenant references must be rejected.

-- submission_current.offline_grant_id: classify as identity, object or immutable revision FK in typed migration; cross-tenant references must be rejected.

CREATE TABLE impact.participant_current (
tenant_id uuid NOT NULL,
object_id uuid NOT NULL,
revision_id uuid NOT NULL,
programme_id uuid,
pseudonym varchar(64),
entity_type varchar(64),
purpose varchar(64),
direct_identifiers jsonb,
PRIMARY KEY(tenant_id,object_id),
FOREIGN KEY(tenant_id,object_id,revision_id) REFERENCES impact.object_revision(tenant_id,object_id,revision_id) DEFERRABLE INITIALLY DEFERRED
);

-- participant_current.programme_id: classify as identity, object or immutable revision FK in typed migration; cross-tenant references must be rejected.

CREATE TABLE impact.service_event_current (
tenant_id uuid NOT NULL,
object_id uuid NOT NULL,
revision_id uuid NOT NULL,
subject_id uuid,
related_subject_id uuid,
event_code varchar(64),
event_at timestamptz,
ends_at timestamptz,
source_namespace varchar(64),
source_key text,
PRIMARY KEY(tenant_id,object_id),
FOREIGN KEY(tenant_id,object_id,revision_id) REFERENCES impact.object_revision(tenant_id,object_id,revision_id) DEFERRABLE INITIALLY DEFERRED
);

-- service_event_current.subject_id: classify as identity, object or immutable revision FK in typed migration; cross-tenant references must be rejected.

-- service_event_current.related_subject_id: classify as identity, object or immutable revision FK in typed migration; cross-tenant references must be rejected.

CREATE TABLE impact.handling_record_current (
tenant_id uuid NOT NULL,
object_id uuid NOT NULL,
revision_id uuid NOT NULL,
subject_id uuid,
notice_version uuid,
purpose varchar(64),
handling_basis varchar(64),
language varchar(64),
scope_id uuid,
effective_at timestamptz,
PRIMARY KEY(tenant_id,object_id),
FOREIGN KEY(tenant_id,object_id,revision_id) REFERENCES impact.object_revision(tenant_id,object_id,revision_id) DEFERRABLE INITIALLY DEFERRED
);

-- handling_record_current.subject_id: classify as identity, object or immutable revision FK in typed migration; cross-tenant references must be rejected.

-- handling_record_current.notice_version: classify as identity, object or immutable revision FK in typed migration; cross-tenant references must be rejected.

-- handling_record_current.scope_id: classify as identity, object or immutable revision FK in typed migration; cross-tenant references must be rejected.

CREATE TABLE impact.dataset_current (
tenant_id uuid NOT NULL,
object_id uuid NOT NULL,
revision_id uuid NOT NULL,
name varchar(200),
purpose varchar(64),
source jsonb,
schema_version varchar(64),
refresh_contract jsonb,
transformation_id uuid,
parent_versions jsonb,
PRIMARY KEY(tenant_id,object_id),
FOREIGN KEY(tenant_id,object_id,revision_id) REFERENCES impact.object_revision(tenant_id,object_id,revision_id) DEFERRABLE INITIALLY DEFERRED
);

-- dataset_current.transformation_id: classify as identity, object or immutable revision FK in typed migration; cross-tenant references must be rejected.

CREATE TABLE impact.import_job_current (
tenant_id uuid NOT NULL,
object_id uuid NOT NULL,
revision_id uuid NOT NULL,
upload_id uuid,
source_namespace varchar(64),
mapping_version uuid,
mode varchar(64),
source_key_policy jsonb,
locale varchar(64),
date_pattern varchar(64),
expected_totals jsonb,
atomic boolean,
PRIMARY KEY(tenant_id,object_id),
FOREIGN KEY(tenant_id,object_id,revision_id) REFERENCES impact.object_revision(tenant_id,object_id,revision_id) DEFERRABLE INITIALLY DEFERRED
);

-- import_job_current.upload_id: classify as identity, object or immutable revision FK in typed migration; cross-tenant references must be rejected.

-- import_job_current.mapping_version: classify as identity, object or immutable revision FK in typed migration; cross-tenant references must be rejected.

CREATE TABLE impact.quality_issue_current (
tenant_id uuid NOT NULL,
object_id uuid NOT NULL,
revision_id uuid NOT NULL,
rule_version uuid,
affected_object_id uuid,
affected_revision_id uuid,
severity varchar(64),
description text,
PRIMARY KEY(tenant_id,object_id),
FOREIGN KEY(tenant_id,object_id,revision_id) REFERENCES impact.object_revision(tenant_id,object_id,revision_id) DEFERRABLE INITIALLY DEFERRED
);

-- quality_issue_current.rule_version: classify as identity, object or immutable revision FK in typed migration; cross-tenant references must be rejected.

-- quality_issue_current.affected_object_id: classify as identity, object or immutable revision FK in typed migration; cross-tenant references must be rejected.

-- quality_issue_current.affected_revision_id: classify as identity, object or immutable revision FK in typed migration; cross-tenant references must be rejected.

CREATE TABLE impact.evidence_current (
tenant_id uuid NOT NULL,
object_id uuid NOT NULL,
revision_id uuid NOT NULL,
upload_id uuid,
external_reference text,
source text,
evidence_date timestamptz,
evidence_type varchar(64),
publication_handling_id uuid,
PRIMARY KEY(tenant_id,object_id),
FOREIGN KEY(tenant_id,object_id,revision_id) REFERENCES impact.object_revision(tenant_id,object_id,revision_id) DEFERRABLE INITIALLY DEFERRED
);

-- evidence_current.upload_id: classify as identity, object or immutable revision FK in typed migration; cross-tenant references must be rejected.

-- evidence_current.publication_handling_id: classify as identity, object or immutable revision FK in typed migration; cross-tenant references must be rejected.

CREATE TABLE impact.workflow_current (
tenant_id uuid NOT NULL,
object_id uuid NOT NULL,
revision_id uuid NOT NULL,
candidate_id uuid,
candidate_revision uuid,
workflow_version uuid,
stages jsonb,
PRIMARY KEY(tenant_id,object_id),
FOREIGN KEY(tenant_id,object_id,revision_id) REFERENCES impact.object_revision(tenant_id,object_id,revision_id) DEFERRABLE INITIALLY DEFERRED
);

-- workflow_current.candidate_id: classify as identity, object or immutable revision FK in typed migration; cross-tenant references must be rejected.

-- workflow_current.candidate_revision: classify as identity, object or immutable revision FK in typed migration; cross-tenant references must be rejected.

-- workflow_current.workflow_version: classify as identity, object or immutable revision FK in typed migration; cross-tenant references must be rejected.

CREATE TABLE impact.decision_current (
tenant_id uuid NOT NULL,
object_id uuid NOT NULL,
revision_id uuid NOT NULL,
candidate_revision uuid,
workflow_version uuid,
action varchar(64),
reason text,
evidence_revisions jsonb,
PRIMARY KEY(tenant_id,object_id),
FOREIGN KEY(tenant_id,object_id,revision_id) REFERENCES impact.object_revision(tenant_id,object_id,revision_id) DEFERRABLE INITIALLY DEFERRED
);

-- decision_current.candidate_revision: classify as identity, object or immutable revision FK in typed migration; cross-tenant references must be rejected.

-- decision_current.workflow_version: classify as identity, object or immutable revision FK in typed migration; cross-tenant references must be rejected.

CREATE TABLE impact.snapshot_current (
tenant_id uuid NOT NULL,
object_id uuid NOT NULL,
revision_id uuid NOT NULL,
scope_id uuid,
period_id uuid,
definition_versions jsonb,
target_versions jsonb,
result_versions jsonb,
evidence_versions jsonb,
policy_context jsonb,
locked_at timestamptz,
PRIMARY KEY(tenant_id,object_id),
FOREIGN KEY(tenant_id,object_id,revision_id) REFERENCES impact.object_revision(tenant_id,object_id,revision_id) DEFERRABLE INITIALLY DEFERRED
);

-- snapshot_current.scope_id: classify as identity, object or immutable revision FK in typed migration; cross-tenant references must be rejected.

-- snapshot_current.period_id: classify as identity, object or immutable revision FK in typed migration; cross-tenant references must be rejected.

CREATE TABLE impact.report_current (
tenant_id uuid NOT NULL,
object_id uuid NOT NULL,
revision_id uuid NOT NULL,
template_version uuid,
snapshot_id uuid,
language varchar(64),
audience_class varchar(64),
sections jsonb,
PRIMARY KEY(tenant_id,object_id),
FOREIGN KEY(tenant_id,object_id,revision_id) REFERENCES impact.object_revision(tenant_id,object_id,revision_id) DEFERRABLE INITIALLY DEFERRED
);

-- report_current.template_version: classify as identity, object or immutable revision FK in typed migration; cross-tenant references must be rejected.

-- report_current.snapshot_id: classify as identity, object or immutable revision FK in typed migration; cross-tenant references must be rejected.

CREATE TABLE impact.disclosure_current (
tenant_id uuid NOT NULL,
object_id uuid NOT NULL,
revision_id uuid NOT NULL,
artifact_version uuid,
recipients jsonb,
purpose varchar(64),
policy_review_id uuid,
expires_at timestamptz,
public boolean,
PRIMARY KEY(tenant_id,object_id),
FOREIGN KEY(tenant_id,object_id,revision_id) REFERENCES impact.object_revision(tenant_id,object_id,revision_id) DEFERRABLE INITIALLY DEFERRED
);

-- disclosure_current.artifact_version: classify as identity, object or immutable revision FK in typed migration; cross-tenant references must be rejected.

-- disclosure_current.policy_review_id: classify as identity, object or immutable revision FK in typed migration; cross-tenant references must be rejected.

CREATE TABLE impact.budget_line_current (
tenant_id uuid NOT NULL,
object_id uuid NOT NULL,
revision_id uuid NOT NULL,
agreement_id uuid,
programme_id uuid,
category varchar(64),
period_id uuid,
amount numeric(38,12),
currency varchar(64),
rate_version uuid,
PRIMARY KEY(tenant_id,object_id),
FOREIGN KEY(tenant_id,object_id,revision_id) REFERENCES impact.object_revision(tenant_id,object_id,revision_id) DEFERRABLE INITIALLY DEFERRED
);

-- budget_line_current.agreement_id: classify as identity, object or immutable revision FK in typed migration; cross-tenant references must be rejected.

-- budget_line_current.programme_id: classify as identity, object or immutable revision FK in typed migration; cross-tenant references must be rejected.

-- budget_line_current.period_id: classify as identity, object or immutable revision FK in typed migration; cross-tenant references must be rejected.

-- budget_line_current.rate_version: classify as identity, object or immutable revision FK in typed migration; cross-tenant references must be rejected.

CREATE TABLE impact.connection_current (
tenant_id uuid NOT NULL,
object_id uuid NOT NULL,
revision_id uuid NOT NULL,
connection_type varchar(64),
scope_id uuid,
credential_reference uuid,
mapping_version uuid,
schedule_id uuid,
PRIMARY KEY(tenant_id,object_id),
FOREIGN KEY(tenant_id,object_id,revision_id) REFERENCES impact.object_revision(tenant_id,object_id,revision_id) DEFERRABLE INITIALLY DEFERRED
);

-- connection_current.scope_id: classify as identity, object or immutable revision FK in typed migration; cross-tenant references must be rejected.

-- connection_current.credential_reference: classify as identity, object or immutable revision FK in typed migration; cross-tenant references must be rejected.

-- connection_current.mapping_version: classify as identity, object or immutable revision FK in typed migration; cross-tenant references must be rejected.

-- connection_current.schedule_id: classify as identity, object or immutable revision FK in typed migration; cross-tenant references must be rejected.

CREATE TABLE impact.a_i_task_current (
tenant_id uuid NOT NULL,
object_id uuid NOT NULL,
revision_id uuid NOT NULL,
use_case varchar(64),
source_revisions jsonb,
configuration_version uuid,
prompt text,
budget_context uuid,
PRIMARY KEY(tenant_id,object_id),
FOREIGN KEY(tenant_id,object_id,revision_id) REFERENCES impact.object_revision(tenant_id,object_id,revision_id) DEFERRABLE INITIALLY DEFERRED
);

-- a_i_task_current.configuration_version: classify as identity, object or immutable revision FK in typed migration; cross-tenant references must be rejected.

-- a_i_task_current.budget_context: classify as identity, object or immutable revision FK in typed migration; cross-tenant references must be rejected.

CREATE TABLE impact.privacy_case_current (
tenant_id uuid NOT NULL,
object_id uuid NOT NULL,
revision_id uuid NOT NULL,
requester_reference uuid,
request_type varchar(64),
scope_id uuid,
handling_authority varchar(64),
deadline timestamptz,
PRIMARY KEY(tenant_id,object_id),
FOREIGN KEY(tenant_id,object_id,revision_id) REFERENCES impact.object_revision(tenant_id,object_id,revision_id) DEFERRABLE INITIALLY DEFERRED
);

-- privacy_case_current.requester_reference: classify as identity, object or immutable revision FK in typed migration; cross-tenant references must be rejected.

-- privacy_case_current.scope_id: classify as identity, object or immutable revision FK in typed migration; cross-tenant references must be rejected.

CREATE TABLE impact.audit_event_current (
tenant_id uuid NOT NULL,
object_id uuid NOT NULL,
revision_id uuid NOT NULL,
real_actor_id uuid,
effective_actor_id uuid,
action_type varchar(64),
object_reference uuid,
outcome varchar(64),
occurred_at timestamptz,
correlation_id uuid,
specification_ref varchar(64),
PRIMARY KEY(tenant_id,object_id),
FOREIGN KEY(tenant_id,object_id,revision_id) REFERENCES impact.object_revision(tenant_id,object_id,revision_id) DEFERRABLE INITIALLY DEFERRED
);

-- audit_event_current.real_actor_id: classify as identity, object or immutable revision FK in typed migration; cross-tenant references must be rejected.

-- audit_event_current.effective_actor_id: classify as identity, object or immutable revision FK in typed migration; cross-tenant references must be rejected.

-- audit_event_current.object_reference: classify as identity, object or immutable revision FK in typed migration; cross-tenant references must be rejected.

-- audit_event_current.correlation_id: classify as identity, object or immutable revision FK in typed migration; cross-tenant references must be rejected.

CREATE TABLE impact.evaluation_current (
tenant_id uuid NOT NULL,
object_id uuid NOT NULL,
revision_id uuid NOT NULL,
questions jsonb,
programme_baseline uuid,
methods text,
study_starts_at timestamptz,
study_ends_at timestamptz,
evaluator_id uuid,
evidence_versions jsonb,
limitations text,
PRIMARY KEY(tenant_id,object_id),
FOREIGN KEY(tenant_id,object_id,revision_id) REFERENCES impact.object_revision(tenant_id,object_id,revision_id) DEFERRABLE INITIALLY DEFERRED
);

-- evaluation_current.programme_baseline: classify as identity, object or immutable revision FK in typed migration; cross-tenant references must be rejected.

-- evaluation_current.evaluator_id: classify as identity, object or immutable revision FK in typed migration; cross-tenant references must be rejected.

CREATE TABLE impact.retention_policy_current (
tenant_id uuid NOT NULL,
object_id uuid NOT NULL,
revision_id uuid NOT NULL,
data_class varchar(64),
purpose varchar(64),
trigger varchar(64),
duration_days integer,
expiry_action varchar(64),
PRIMARY KEY(tenant_id,object_id),
FOREIGN KEY(tenant_id,object_id,revision_id) REFERENCES impact.object_revision(tenant_id,object_id,revision_id) DEFERRABLE INITIALLY DEFERRED
);

CREATE TABLE impact.subscription_current (
tenant_id uuid NOT NULL,
object_id uuid NOT NULL,
revision_id uuid NOT NULL,
plan_reference varchar(64),
effective_at timestamptz,
ends_at timestamptz,
authorised_limits jsonb,
billing_contact_id uuid,
PRIMARY KEY(tenant_id,object_id),
FOREIGN KEY(tenant_id,object_id,revision_id) REFERENCES impact.object_revision(tenant_id,object_id,revision_id) DEFERRABLE INITIALLY DEFERRED
);

-- subscription_current.billing_contact_id: classify as identity, object or immutable revision FK in typed migration; cross-tenant references must be rejected.

CREATE TABLE impact.funding_agreement_current (
tenant_id uuid NOT NULL,
object_id uuid NOT NULL,
revision_id uuid NOT NULL,
code varchar(64),
donor_reference text,
starts_at timestamptz,
ends_at timestamptz,
currency varchar(64),
ceiling numeric(38,12),
restrictions jsonb,
PRIMARY KEY(tenant_id,object_id),
FOREIGN KEY(tenant_id,object_id,revision_id) REFERENCES impact.object_revision(tenant_id,object_id,revision_id) DEFERRABLE INITIALLY DEFERRED
);

CREATE TABLE impact.finance_transaction_current (
tenant_id uuid NOT NULL,
object_id uuid NOT NULL,
revision_id uuid NOT NULL,
source_namespace varchar(64),
source_key text,
programme_id uuid,
amount numeric(38,12),
currency varchar(64),
posting_at timestamptz,
event_at timestamptz,
category varchar(64),
reversal_of uuid,
PRIMARY KEY(tenant_id,object_id),
FOREIGN KEY(tenant_id,object_id,revision_id) REFERENCES impact.object_revision(tenant_id,object_id,revision_id) DEFERRABLE INITIALLY DEFERRED
);

-- finance_transaction_current.programme_id: classify as identity, object or immutable revision FK in typed migration; cross-tenant references must be rejected.

-- finance_transaction_current.reversal_of: classify as identity, object or immutable revision FK in typed migration; cross-tenant references must be rejected.

CREATE TABLE impact.exchange_rate_current (
tenant_id uuid NOT NULL,
object_id uuid NOT NULL,
revision_id uuid NOT NULL,
source_currency varchar(64),
reporting_currency varchar(64),
rate numeric(38,12),
effective_at timestamptz,
source text,
PRIMARY KEY(tenant_id,object_id),
FOREIGN KEY(tenant_id,object_id,revision_id) REFERENCES impact.object_revision(tenant_id,object_id,revision_id) DEFERRABLE INITIALLY DEFERRED,
CHECK (rate > 0)
);

CREATE TABLE impact.allocation_rule_current (
tenant_id uuid NOT NULL,
object_id uuid NOT NULL,
revision_id uuid NOT NULL,
basis varchar(64),
weights jsonb,
residual_order jsonb,
PRIMARY KEY(tenant_id,object_id),
FOREIGN KEY(tenant_id,object_id,revision_id) REFERENCES impact.object_revision(tenant_id,object_id,revision_id) DEFERRABLE INITIALLY DEFERRED
);

CREATE TABLE impact.work_item_current (
tenant_id uuid NOT NULL,
object_id uuid NOT NULL,
revision_id uuid NOT NULL,
programme_id uuid,
work_type varchar(64),
title varchar(200),
parent_id uuid,
dependency_ids jsonb,
due_at timestamptz,
assignee_id uuid,
severity varchar(64),
PRIMARY KEY(tenant_id,object_id),
FOREIGN KEY(tenant_id,object_id,revision_id) REFERENCES impact.object_revision(tenant_id,object_id,revision_id) DEFERRABLE INITIALLY DEFERRED
);

-- work_item_current.programme_id: classify as identity, object or immutable revision FK in typed migration; cross-tenant references must be rejected.

-- work_item_current.parent_id: classify as identity, object or immutable revision FK in typed migration; cross-tenant references must be rejected.

-- work_item_current.assignee_id: classify as identity, object or immutable revision FK in typed migration; cross-tenant references must be rejected.

CREATE TABLE impact.dashboard_current (
tenant_id uuid NOT NULL,
object_id uuid NOT NULL,
revision_id uuid NOT NULL,
title varchar(200),
mode varchar(64),
widgets jsonb,
filters jsonb,
PRIMARY KEY(tenant_id,object_id),
FOREIGN KEY(tenant_id,object_id,revision_id) REFERENCES impact.object_revision(tenant_id,object_id,revision_id) DEFERRABLE INITIALLY DEFERRED
);

CREATE TABLE impact.report_template_current (
tenant_id uuid NOT NULL,
object_id uuid NOT NULL,
revision_id uuid NOT NULL,
title varchar(200),
language varchar(64),
sections jsonb,
numeric_bindings jsonb,
PRIMARY KEY(tenant_id,object_id),
FOREIGN KEY(tenant_id,object_id,revision_id) REFERENCES impact.object_revision(tenant_id,object_id,revision_id) DEFERRABLE INITIALLY DEFERRED
);

CREATE TABLE impact.notification_current (
tenant_id uuid NOT NULL,
object_id uuid NOT NULL,
revision_id uuid NOT NULL,
event_id uuid,
recipient_id uuid,
channel varchar(64),
notice_class varchar(64),
safe_reference uuid,
PRIMARY KEY(tenant_id,object_id),
FOREIGN KEY(tenant_id,object_id,revision_id) REFERENCES impact.object_revision(tenant_id,object_id,revision_id) DEFERRABLE INITIALLY DEFERRED
);

-- notification_current.event_id: classify as identity, object or immutable revision FK in typed migration; cross-tenant references must be rejected.

-- notification_current.recipient_id: classify as identity, object or immutable revision FK in typed migration; cross-tenant references must be rejected.

-- notification_current.safe_reference: classify as identity, object or immutable revision FK in typed migration; cross-tenant references must be rejected.

CREATE TABLE impact.schedule_current (
tenant_id uuid NOT NULL,
object_id uuid NOT NULL,
revision_id uuid NOT NULL,
command_type varchar(64),
service_identity_id uuid,
scope_id uuid,
timezone text,
expression text,
missed_run_policy varchar(64),
PRIMARY KEY(tenant_id,object_id),
FOREIGN KEY(tenant_id,object_id,revision_id) REFERENCES impact.object_revision(tenant_id,object_id,revision_id) DEFERRABLE INITIALLY DEFERRED
);

-- schedule_current.service_identity_id: classify as identity, object or immutable revision FK in typed migration; cross-tenant references must be rejected.

-- schedule_current.scope_id: classify as identity, object or immutable revision FK in typed migration; cross-tenant references must be rejected.

CREATE TABLE impact.qualitative_extract_current (
tenant_id uuid NOT NULL,
object_id uuid NOT NULL,
revision_id uuid NOT NULL,
evidence_version uuid,
source_span jsonb,
codebook_version uuid,
assigned_codes jsonb,
interpretation text,
PRIMARY KEY(tenant_id,object_id),
FOREIGN KEY(tenant_id,object_id,revision_id) REFERENCES impact.object_revision(tenant_id,object_id,revision_id) DEFERRABLE INITIALLY DEFERRED
);

-- qualitative_extract_current.evidence_version: classify as identity, object or immutable revision FK in typed migration; cross-tenant references must be rejected.

-- qualitative_extract_current.codebook_version: classify as identity, object or immutable revision FK in typed migration; cross-tenant references must be rejected.

CREATE TABLE impact.device_current (
tenant_id uuid NOT NULL,
object_id uuid NOT NULL,
revision_id uuid NOT NULL,
public_key text,
security_profile varchar(64),
attestation_reference uuid,
PRIMARY KEY(tenant_id,object_id),
FOREIGN KEY(tenant_id,object_id,revision_id) REFERENCES impact.object_revision(tenant_id,object_id,revision_id) DEFERRABLE INITIALLY DEFERRED
);

-- device_current.attestation_reference: classify as identity, object or immutable revision FK in typed migration; cross-tenant references must be rejected.

CREATE TABLE impact.support_request_current (
tenant_id uuid NOT NULL,
object_id uuid NOT NULL,
revision_id uuid NOT NULL,
scope_id uuid,
reason text,
requested_capabilities jsonb,
requested_expires_at timestamptz,
PRIMARY KEY(tenant_id,object_id),
FOREIGN KEY(tenant_id,object_id,revision_id) REFERENCES impact.object_revision(tenant_id,object_id,revision_id) DEFERRABLE INITIALLY DEFERRED
);

-- support_request_current.scope_id: classify as identity, object or immutable revision FK in typed migration; cross-tenant references must be rejected.

CREATE TABLE impact.access_epoch (tenant_id uuid NOT NULL REFERENCES impact.tenant_root, subject_id uuid NOT NULL, epoch bigint NOT NULL DEFAULT 0, PRIMARY KEY(tenant_id,subject_id));

CREATE TABLE impact.operation_receipt (tenant_id uuid NOT NULL REFERENCES impact.tenant_root, actor_id uuid NOT NULL, command_type text NOT NULL, operation_id uuid NOT NULL, payload_hash bytea NOT NULL, state text NOT NULL, outcome jsonb, expires_at timestamptz NOT NULL, PRIMARY KEY(tenant_id,actor_id,command_type,operation_id));

CREATE TABLE impact.source_key_registry (tenant_id uuid NOT NULL REFERENCES impact.tenant_root, namespace text NOT NULL, source_key text NOT NULL, object_id uuid NOT NULL, PRIMARY KEY(tenant_id,namespace,source_key), FOREIGN KEY(tenant_id,object_id) REFERENCES impact.object_registry);

CREATE TABLE impact.source_revision_receipt (tenant_id uuid NOT NULL REFERENCES impact.tenant_root, namespace text NOT NULL, source_key text NOT NULL, source_revision text NOT NULL, content_hash bytea NOT NULL, destination_revision uuid NOT NULL, PRIMARY KEY(tenant_id,namespace,source_key,source_revision), FOREIGN KEY(tenant_id,destination_revision) REFERENCES impact.object_revision(tenant_id,revision_id));

CREATE TABLE impact.workflow_author (tenant_id uuid NOT NULL REFERENCES impact.tenant_root, workflow_id uuid NOT NULL, natural_identity_id uuid NOT NULL, candidate_revision uuid NOT NULL, PRIMARY KEY(tenant_id,workflow_id,natural_identity_id,candidate_revision));

CREATE TABLE impact.review_decision (tenant_id uuid NOT NULL REFERENCES impact.tenant_root, decision_id uuid NOT NULL, workflow_id uuid NOT NULL, stage_id uuid NOT NULL, natural_identity_id uuid NOT NULL, candidate_revision uuid NOT NULL, decision text NOT NULL, decided_at timestamptz NOT NULL, PRIMARY KEY(tenant_id,decision_id), UNIQUE(tenant_id,workflow_id,stage_id,natural_identity_id,candidate_revision));

CREATE TABLE impact.lineage_edge (tenant_id uuid NOT NULL REFERENCES impact.tenant_root, result_revision uuid NOT NULL, source_revision uuid NOT NULL, contribution_identity text NOT NULL, disposition text NOT NULL, reason_code text, PRIMARY KEY(tenant_id,result_revision,source_revision,contribution_identity));

CREATE TABLE impact.snapshot_member (tenant_id uuid NOT NULL REFERENCES impact.tenant_root, snapshot_id uuid NOT NULL, member_revision uuid NOT NULL, member_type text NOT NULL, PRIMARY KEY(tenant_id,snapshot_id,member_revision));

CREATE TABLE impact.file_blob (tenant_id uuid NOT NULL REFERENCES impact.tenant_root, blob_id uuid NOT NULL, object_key text NOT NULL, sha256 bytea NOT NULL, bytes bigint NOT NULL CHECK(bytes>0), scan_state text NOT NULL, classification text NOT NULL, PRIMARY KEY(tenant_id,blob_id));

CREATE TABLE impact.offline_grant (tenant_id uuid NOT NULL REFERENCES impact.tenant_root, grant_id uuid NOT NULL, subject_id uuid NOT NULL, device_id uuid NOT NULL, scope_id uuid NOT NULL, issued_at timestamptz NOT NULL, expires_at timestamptz NOT NULL, policy_epoch bigint NOT NULL, signed_manifest jsonb NOT NULL, PRIMARY KEY(tenant_id,grant_id), CHECK(expires_at>issued_at));

CREATE TABLE impact.sync_receipt (tenant_id uuid NOT NULL REFERENCES impact.tenant_root, device_id uuid NOT NULL, submission_id uuid NOT NULL, object_id uuid NOT NULL, content_hash bytea NOT NULL, receipt jsonb NOT NULL, PRIMARY KEY(tenant_id,device_id,submission_id));

CREATE TABLE impact.job (tenant_id uuid NOT NULL REFERENCES impact.tenant_root, job_id uuid NOT NULL, job_class text NOT NULL, requester_id uuid NOT NULL, service_identity_id uuid, scope_id uuid NOT NULL, state text NOT NULL, lease_generation bigint NOT NULL DEFAULT 0, lease_expires_at timestamptz, cancellation_requested_at timestamptz, input_manifest jsonb NOT NULL, output_manifest jsonb, PRIMARY KEY(tenant_id,job_id));

CREATE TABLE impact.job_item (tenant_id uuid NOT NULL REFERENCES impact.tenant_root, job_id uuid NOT NULL, item_key text NOT NULL, outcome text NOT NULL, destination_revision uuid, error_code text, PRIMARY KEY(tenant_id,job_id,item_key));

CREATE TABLE impact.outbox_event (tenant_id uuid NOT NULL REFERENCES impact.tenant_root, event_id uuid NOT NULL, event_type text NOT NULL, occurred_at timestamptz NOT NULL, payload jsonb NOT NULL, sent_at timestamptz, PRIMARY KEY(tenant_id,event_id));

CREATE TABLE impact.consumer_receipt (tenant_id uuid NOT NULL REFERENCES impact.tenant_root, consumer text NOT NULL, event_id uuid NOT NULL, applied_at timestamptz NOT NULL, PRIMARY KEY(tenant_id,consumer,event_id));

CREATE TABLE impact.deletion_ledger (tenant_id uuid NOT NULL REFERENCES impact.tenant_root, entry_id uuid NOT NULL, case_id uuid NOT NULL, object_id uuid NOT NULL, effective_at timestamptz NOT NULL, disposition text NOT NULL, PRIMARY KEY(tenant_id,entry_id));

CREATE TABLE impact.retention_hold (tenant_id uuid NOT NULL REFERENCES impact.tenant_root, hold_id uuid NOT NULL, object_id uuid NOT NULL, authority_reference text NOT NULL, review_at timestamptz NOT NULL, released_at timestamptz, PRIMARY KEY(tenant_id,hold_id));

CREATE TABLE impact.webhook_delivery (tenant_id uuid NOT NULL REFERENCES impact.tenant_root, event_id uuid NOT NULL, destination_id uuid NOT NULL, delivery_id uuid NOT NULL, attempt integer NOT NULL, outcome text NOT NULL, PRIMARY KEY(tenant_id,delivery_id), UNIQUE(tenant_id,event_id,destination_id,attempt));

CREATE TABLE impact.audit_batch_root (tenant_id uuid NOT NULL REFERENCES impact.tenant_root, batch_id uuid NOT NULL, starts_at timestamptz NOT NULL, ends_at timestamptz NOT NULL, root_digest bytea NOT NULL, previous_digest bytea, external_checkpoint text NOT NULL, PRIMARY KEY(tenant_id,batch_id));

CREATE TABLE impact.application_session (tenant_id uuid NOT NULL REFERENCES impact.tenant_root, session_id uuid NOT NULL, subject_id uuid NOT NULL, token_hash bytea NOT NULL, issued_at timestamptz NOT NULL, last_active_at timestamptz NOT NULL, absolute_expires_at timestamptz NOT NULL, assurance_at timestamptz, revoked_at timestamptz, PRIMARY KEY(tenant_id,session_id));

CREATE TABLE impact.member_invitation (tenant_id uuid NOT NULL REFERENCES impact.tenant_root, invitation_id uuid NOT NULL, token_hash bytea NOT NULL UNIQUE, intended_identity jsonb NOT NULL, inviter_id uuid NOT NULL, role_template_id uuid NOT NULL, scope_ids jsonb NOT NULL, expires_at timestamptz NOT NULL, consumed_at timestamptz, revoked_at timestamptz, PRIMARY KEY(tenant_id,invitation_id));

CREATE TABLE impact.scope_definition (tenant_id uuid NOT NULL REFERENCES impact.tenant_root, scope_id uuid NOT NULL, scope_type text NOT NULL, predicate_version uuid NOT NULL, PRIMARY KEY(tenant_id,scope_id));

CREATE TABLE impact.scope_member (tenant_id uuid NOT NULL REFERENCES impact.tenant_root, scope_id uuid NOT NULL, object_id uuid NOT NULL, PRIMARY KEY(tenant_id,scope_id,object_id), FOREIGN KEY(tenant_id,object_id) REFERENCES impact.object_registry);

CREATE TABLE impact.service_identity (tenant_id uuid NOT NULL REFERENCES impact.tenant_root, service_identity_id uuid NOT NULL, owner_id uuid NOT NULL, backup_owner_id uuid NOT NULL, credential_reference text NOT NULL, expires_at timestamptz NOT NULL, PRIMARY KEY(tenant_id,service_identity_id));

CREATE TABLE impact.upload_session (tenant_id uuid NOT NULL REFERENCES impact.tenant_root, upload_id uuid NOT NULL, owner_id uuid NOT NULL, purpose text NOT NULL, expected_bytes bigint NOT NULL, expected_digest bytea NOT NULL, received_bytes bigint NOT NULL DEFAULT 0, state text NOT NULL, expires_at timestamptz NOT NULL, PRIMARY KEY(tenant_id,upload_id));

ALTER TABLE impact.tenant_root ENABLE ROW LEVEL SECURITY;
ALTER TABLE impact.tenant_root FORCE ROW LEVEL SECURITY;
CREATE POLICY tenant_fence ON impact.tenant_root USING (tenant_id = nullif(current_setting('impact.tenant_id',true),'')::uuid) WITH CHECK (tenant_id = nullif(current_setting('impact.tenant_id',true),'')::uuid);

ALTER TABLE impact.object_registry ENABLE ROW LEVEL SECURITY;
ALTER TABLE impact.object_registry FORCE ROW LEVEL SECURITY;
CREATE POLICY tenant_fence ON impact.object_registry USING (tenant_id = nullif(current_setting('impact.tenant_id',true),'')::uuid) WITH CHECK (tenant_id = nullif(current_setting('impact.tenant_id',true),'')::uuid);

ALTER TABLE impact.object_revision ENABLE ROW LEVEL SECURITY;
ALTER TABLE impact.object_revision FORCE ROW LEVEL SECURITY;
CREATE POLICY tenant_fence ON impact.object_revision USING (tenant_id = nullif(current_setting('impact.tenant_id',true),'')::uuid) WITH CHECK (tenant_id = nullif(current_setting('impact.tenant_id',true),'')::uuid);

ALTER TABLE impact.tenant_current ENABLE ROW LEVEL SECURITY;
ALTER TABLE impact.tenant_current FORCE ROW LEVEL SECURITY;
CREATE POLICY tenant_fence ON impact.tenant_current USING (tenant_id = nullif(current_setting('impact.tenant_id',true),'')::uuid) WITH CHECK (tenant_id = nullif(current_setting('impact.tenant_id',true),'')::uuid);

ALTER TABLE impact.membership_current ENABLE ROW LEVEL SECURITY;
ALTER TABLE impact.membership_current FORCE ROW LEVEL SECURITY;
CREATE POLICY tenant_fence ON impact.membership_current USING (tenant_id = nullif(current_setting('impact.tenant_id',true),'')::uuid) WITH CHECK (tenant_id = nullif(current_setting('impact.tenant_id',true),'')::uuid);

ALTER TABLE impact.grant_current ENABLE ROW LEVEL SECURITY;
ALTER TABLE impact.grant_current FORCE ROW LEVEL SECURITY;
CREATE POLICY tenant_fence ON impact.grant_current USING (tenant_id = nullif(current_setting('impact.tenant_id',true),'')::uuid) WITH CHECK (tenant_id = nullif(current_setting('impact.tenant_id',true),'')::uuid);

ALTER TABLE impact.organisation_unit_current ENABLE ROW LEVEL SECURITY;
ALTER TABLE impact.organisation_unit_current FORCE ROW LEVEL SECURITY;
CREATE POLICY tenant_fence ON impact.organisation_unit_current USING (tenant_id = nullif(current_setting('impact.tenant_id',true),'')::uuid) WITH CHECK (tenant_id = nullif(current_setting('impact.tenant_id',true),'')::uuid);

ALTER TABLE impact.programme_current ENABLE ROW LEVEL SECURITY;
ALTER TABLE impact.programme_current FORCE ROW LEVEL SECURITY;
CREATE POLICY tenant_fence ON impact.programme_current USING (tenant_id = nullif(current_setting('impact.tenant_id',true),'')::uuid) WITH CHECK (tenant_id = nullif(current_setting('impact.tenant_id',true),'')::uuid);

ALTER TABLE impact.framework_current ENABLE ROW LEVEL SECURITY;
ALTER TABLE impact.framework_current FORCE ROW LEVEL SECURITY;
CREATE POLICY tenant_fence ON impact.framework_current USING (tenant_id = nullif(current_setting('impact.tenant_id',true),'')::uuid) WITH CHECK (tenant_id = nullif(current_setting('impact.tenant_id',true),'')::uuid);

ALTER TABLE impact.indicator_definition_current ENABLE ROW LEVEL SECURITY;
ALTER TABLE impact.indicator_definition_current FORCE ROW LEVEL SECURITY;
CREATE POLICY tenant_fence ON impact.indicator_definition_current USING (tenant_id = nullif(current_setting('impact.tenant_id',true),'')::uuid) WITH CHECK (tenant_id = nullif(current_setting('impact.tenant_id',true),'')::uuid);

ALTER TABLE impact.indicator_instance_current ENABLE ROW LEVEL SECURITY;
ALTER TABLE impact.indicator_instance_current FORCE ROW LEVEL SECURITY;
CREATE POLICY tenant_fence ON impact.indicator_instance_current USING (tenant_id = nullif(current_setting('impact.tenant_id',true),'')::uuid) WITH CHECK (tenant_id = nullif(current_setting('impact.tenant_id',true),'')::uuid);

ALTER TABLE impact.target_current ENABLE ROW LEVEL SECURITY;
ALTER TABLE impact.target_current FORCE ROW LEVEL SECURITY;
CREATE POLICY tenant_fence ON impact.target_current USING (tenant_id = nullif(current_setting('impact.tenant_id',true),'')::uuid) WITH CHECK (tenant_id = nullif(current_setting('impact.tenant_id',true),'')::uuid);

ALTER TABLE impact.dimension_current ENABLE ROW LEVEL SECURITY;
ALTER TABLE impact.dimension_current FORCE ROW LEVEL SECURITY;
CREATE POLICY tenant_fence ON impact.dimension_current USING (tenant_id = nullif(current_setting('impact.tenant_id',true),'')::uuid) WITH CHECK (tenant_id = nullif(current_setting('impact.tenant_id',true),'')::uuid);

ALTER TABLE impact.period_current ENABLE ROW LEVEL SECURITY;
ALTER TABLE impact.period_current FORCE ROW LEVEL SECURITY;
CREATE POLICY tenant_fence ON impact.period_current USING (tenant_id = nullif(current_setting('impact.tenant_id',true),'')::uuid) WITH CHECK (tenant_id = nullif(current_setting('impact.tenant_id',true),'')::uuid);

ALTER TABLE impact.observation_current ENABLE ROW LEVEL SECURITY;
ALTER TABLE impact.observation_current FORCE ROW LEVEL SECURITY;
CREATE POLICY tenant_fence ON impact.observation_current USING (tenant_id = nullif(current_setting('impact.tenant_id',true),'')::uuid) WITH CHECK (tenant_id = nullif(current_setting('impact.tenant_id',true),'')::uuid);

ALTER TABLE impact.observation_p00 ENABLE ROW LEVEL SECURITY;
ALTER TABLE impact.observation_p00 FORCE ROW LEVEL SECURITY;
CREATE POLICY tenant_fence ON impact.observation_p00 USING (tenant_id = nullif(current_setting('impact.tenant_id',true),'')::uuid) WITH CHECK (tenant_id = nullif(current_setting('impact.tenant_id',true),'')::uuid);

ALTER TABLE impact.observation_p01 ENABLE ROW LEVEL SECURITY;
ALTER TABLE impact.observation_p01 FORCE ROW LEVEL SECURITY;
CREATE POLICY tenant_fence ON impact.observation_p01 USING (tenant_id = nullif(current_setting('impact.tenant_id',true),'')::uuid) WITH CHECK (tenant_id = nullif(current_setting('impact.tenant_id',true),'')::uuid);

ALTER TABLE impact.observation_p02 ENABLE ROW LEVEL SECURITY;
ALTER TABLE impact.observation_p02 FORCE ROW LEVEL SECURITY;
CREATE POLICY tenant_fence ON impact.observation_p02 USING (tenant_id = nullif(current_setting('impact.tenant_id',true),'')::uuid) WITH CHECK (tenant_id = nullif(current_setting('impact.tenant_id',true),'')::uuid);

ALTER TABLE impact.observation_p03 ENABLE ROW LEVEL SECURITY;
ALTER TABLE impact.observation_p03 FORCE ROW LEVEL SECURITY;
CREATE POLICY tenant_fence ON impact.observation_p03 USING (tenant_id = nullif(current_setting('impact.tenant_id',true),'')::uuid) WITH CHECK (tenant_id = nullif(current_setting('impact.tenant_id',true),'')::uuid);

ALTER TABLE impact.observation_p04 ENABLE ROW LEVEL SECURITY;
ALTER TABLE impact.observation_p04 FORCE ROW LEVEL SECURITY;
CREATE POLICY tenant_fence ON impact.observation_p04 USING (tenant_id = nullif(current_setting('impact.tenant_id',true),'')::uuid) WITH CHECK (tenant_id = nullif(current_setting('impact.tenant_id',true),'')::uuid);

ALTER TABLE impact.observation_p05 ENABLE ROW LEVEL SECURITY;
ALTER TABLE impact.observation_p05 FORCE ROW LEVEL SECURITY;
CREATE POLICY tenant_fence ON impact.observation_p05 USING (tenant_id = nullif(current_setting('impact.tenant_id',true),'')::uuid) WITH CHECK (tenant_id = nullif(current_setting('impact.tenant_id',true),'')::uuid);

ALTER TABLE impact.observation_p06 ENABLE ROW LEVEL SECURITY;
ALTER TABLE impact.observation_p06 FORCE ROW LEVEL SECURITY;
CREATE POLICY tenant_fence ON impact.observation_p06 USING (tenant_id = nullif(current_setting('impact.tenant_id',true),'')::uuid) WITH CHECK (tenant_id = nullif(current_setting('impact.tenant_id',true),'')::uuid);

ALTER TABLE impact.observation_p07 ENABLE ROW LEVEL SECURITY;
ALTER TABLE impact.observation_p07 FORCE ROW LEVEL SECURITY;
CREATE POLICY tenant_fence ON impact.observation_p07 USING (tenant_id = nullif(current_setting('impact.tenant_id',true),'')::uuid) WITH CHECK (tenant_id = nullif(current_setting('impact.tenant_id',true),'')::uuid);

ALTER TABLE impact.observation_p08 ENABLE ROW LEVEL SECURITY;
ALTER TABLE impact.observation_p08 FORCE ROW LEVEL SECURITY;
CREATE POLICY tenant_fence ON impact.observation_p08 USING (tenant_id = nullif(current_setting('impact.tenant_id',true),'')::uuid) WITH CHECK (tenant_id = nullif(current_setting('impact.tenant_id',true),'')::uuid);

ALTER TABLE impact.observation_p09 ENABLE ROW LEVEL SECURITY;
ALTER TABLE impact.observation_p09 FORCE ROW LEVEL SECURITY;
CREATE POLICY tenant_fence ON impact.observation_p09 USING (tenant_id = nullif(current_setting('impact.tenant_id',true),'')::uuid) WITH CHECK (tenant_id = nullif(current_setting('impact.tenant_id',true),'')::uuid);

ALTER TABLE impact.observation_p10 ENABLE ROW LEVEL SECURITY;
ALTER TABLE impact.observation_p10 FORCE ROW LEVEL SECURITY;
CREATE POLICY tenant_fence ON impact.observation_p10 USING (tenant_id = nullif(current_setting('impact.tenant_id',true),'')::uuid) WITH CHECK (tenant_id = nullif(current_setting('impact.tenant_id',true),'')::uuid);

ALTER TABLE impact.observation_p11 ENABLE ROW LEVEL SECURITY;
ALTER TABLE impact.observation_p11 FORCE ROW LEVEL SECURITY;
CREATE POLICY tenant_fence ON impact.observation_p11 USING (tenant_id = nullif(current_setting('impact.tenant_id',true),'')::uuid) WITH CHECK (tenant_id = nullif(current_setting('impact.tenant_id',true),'')::uuid);

ALTER TABLE impact.observation_p12 ENABLE ROW LEVEL SECURITY;
ALTER TABLE impact.observation_p12 FORCE ROW LEVEL SECURITY;
CREATE POLICY tenant_fence ON impact.observation_p12 USING (tenant_id = nullif(current_setting('impact.tenant_id',true),'')::uuid) WITH CHECK (tenant_id = nullif(current_setting('impact.tenant_id',true),'')::uuid);

ALTER TABLE impact.observation_p13 ENABLE ROW LEVEL SECURITY;
ALTER TABLE impact.observation_p13 FORCE ROW LEVEL SECURITY;
CREATE POLICY tenant_fence ON impact.observation_p13 USING (tenant_id = nullif(current_setting('impact.tenant_id',true),'')::uuid) WITH CHECK (tenant_id = nullif(current_setting('impact.tenant_id',true),'')::uuid);

ALTER TABLE impact.observation_p14 ENABLE ROW LEVEL SECURITY;
ALTER TABLE impact.observation_p14 FORCE ROW LEVEL SECURITY;
CREATE POLICY tenant_fence ON impact.observation_p14 USING (tenant_id = nullif(current_setting('impact.tenant_id',true),'')::uuid) WITH CHECK (tenant_id = nullif(current_setting('impact.tenant_id',true),'')::uuid);

ALTER TABLE impact.observation_p15 ENABLE ROW LEVEL SECURITY;
ALTER TABLE impact.observation_p15 FORCE ROW LEVEL SECURITY;
CREATE POLICY tenant_fence ON impact.observation_p15 USING (tenant_id = nullif(current_setting('impact.tenant_id',true),'')::uuid) WITH CHECK (tenant_id = nullif(current_setting('impact.tenant_id',true),'')::uuid);

ALTER TABLE impact.observation_p16 ENABLE ROW LEVEL SECURITY;
ALTER TABLE impact.observation_p16 FORCE ROW LEVEL SECURITY;
CREATE POLICY tenant_fence ON impact.observation_p16 USING (tenant_id = nullif(current_setting('impact.tenant_id',true),'')::uuid) WITH CHECK (tenant_id = nullif(current_setting('impact.tenant_id',true),'')::uuid);

ALTER TABLE impact.observation_p17 ENABLE ROW LEVEL SECURITY;
ALTER TABLE impact.observation_p17 FORCE ROW LEVEL SECURITY;
CREATE POLICY tenant_fence ON impact.observation_p17 USING (tenant_id = nullif(current_setting('impact.tenant_id',true),'')::uuid) WITH CHECK (tenant_id = nullif(current_setting('impact.tenant_id',true),'')::uuid);

ALTER TABLE impact.observation_p18 ENABLE ROW LEVEL SECURITY;
ALTER TABLE impact.observation_p18 FORCE ROW LEVEL SECURITY;
CREATE POLICY tenant_fence ON impact.observation_p18 USING (tenant_id = nullif(current_setting('impact.tenant_id',true),'')::uuid) WITH CHECK (tenant_id = nullif(current_setting('impact.tenant_id',true),'')::uuid);

ALTER TABLE impact.observation_p19 ENABLE ROW LEVEL SECURITY;
ALTER TABLE impact.observation_p19 FORCE ROW LEVEL SECURITY;
CREATE POLICY tenant_fence ON impact.observation_p19 USING (tenant_id = nullif(current_setting('impact.tenant_id',true),'')::uuid) WITH CHECK (tenant_id = nullif(current_setting('impact.tenant_id',true),'')::uuid);

ALTER TABLE impact.observation_p20 ENABLE ROW LEVEL SECURITY;
ALTER TABLE impact.observation_p20 FORCE ROW LEVEL SECURITY;
CREATE POLICY tenant_fence ON impact.observation_p20 USING (tenant_id = nullif(current_setting('impact.tenant_id',true),'')::uuid) WITH CHECK (tenant_id = nullif(current_setting('impact.tenant_id',true),'')::uuid);

ALTER TABLE impact.observation_p21 ENABLE ROW LEVEL SECURITY;
ALTER TABLE impact.observation_p21 FORCE ROW LEVEL SECURITY;
CREATE POLICY tenant_fence ON impact.observation_p21 USING (tenant_id = nullif(current_setting('impact.tenant_id',true),'')::uuid) WITH CHECK (tenant_id = nullif(current_setting('impact.tenant_id',true),'')::uuid);

ALTER TABLE impact.observation_p22 ENABLE ROW LEVEL SECURITY;
ALTER TABLE impact.observation_p22 FORCE ROW LEVEL SECURITY;
CREATE POLICY tenant_fence ON impact.observation_p22 USING (tenant_id = nullif(current_setting('impact.tenant_id',true),'')::uuid) WITH CHECK (tenant_id = nullif(current_setting('impact.tenant_id',true),'')::uuid);

ALTER TABLE impact.observation_p23 ENABLE ROW LEVEL SECURITY;
ALTER TABLE impact.observation_p23 FORCE ROW LEVEL SECURITY;
CREATE POLICY tenant_fence ON impact.observation_p23 USING (tenant_id = nullif(current_setting('impact.tenant_id',true),'')::uuid) WITH CHECK (tenant_id = nullif(current_setting('impact.tenant_id',true),'')::uuid);

ALTER TABLE impact.observation_p24 ENABLE ROW LEVEL SECURITY;
ALTER TABLE impact.observation_p24 FORCE ROW LEVEL SECURITY;
CREATE POLICY tenant_fence ON impact.observation_p24 USING (tenant_id = nullif(current_setting('impact.tenant_id',true),'')::uuid) WITH CHECK (tenant_id = nullif(current_setting('impact.tenant_id',true),'')::uuid);

ALTER TABLE impact.observation_p25 ENABLE ROW LEVEL SECURITY;
ALTER TABLE impact.observation_p25 FORCE ROW LEVEL SECURITY;
CREATE POLICY tenant_fence ON impact.observation_p25 USING (tenant_id = nullif(current_setting('impact.tenant_id',true),'')::uuid) WITH CHECK (tenant_id = nullif(current_setting('impact.tenant_id',true),'')::uuid);

ALTER TABLE impact.observation_p26 ENABLE ROW LEVEL SECURITY;
ALTER TABLE impact.observation_p26 FORCE ROW LEVEL SECURITY;
CREATE POLICY tenant_fence ON impact.observation_p26 USING (tenant_id = nullif(current_setting('impact.tenant_id',true),'')::uuid) WITH CHECK (tenant_id = nullif(current_setting('impact.tenant_id',true),'')::uuid);

ALTER TABLE impact.observation_p27 ENABLE ROW LEVEL SECURITY;
ALTER TABLE impact.observation_p27 FORCE ROW LEVEL SECURITY;
CREATE POLICY tenant_fence ON impact.observation_p27 USING (tenant_id = nullif(current_setting('impact.tenant_id',true),'')::uuid) WITH CHECK (tenant_id = nullif(current_setting('impact.tenant_id',true),'')::uuid);

ALTER TABLE impact.observation_p28 ENABLE ROW LEVEL SECURITY;
ALTER TABLE impact.observation_p28 FORCE ROW LEVEL SECURITY;
CREATE POLICY tenant_fence ON impact.observation_p28 USING (tenant_id = nullif(current_setting('impact.tenant_id',true),'')::uuid) WITH CHECK (tenant_id = nullif(current_setting('impact.tenant_id',true),'')::uuid);

ALTER TABLE impact.observation_p29 ENABLE ROW LEVEL SECURITY;
ALTER TABLE impact.observation_p29 FORCE ROW LEVEL SECURITY;
CREATE POLICY tenant_fence ON impact.observation_p29 USING (tenant_id = nullif(current_setting('impact.tenant_id',true),'')::uuid) WITH CHECK (tenant_id = nullif(current_setting('impact.tenant_id',true),'')::uuid);

ALTER TABLE impact.observation_p30 ENABLE ROW LEVEL SECURITY;
ALTER TABLE impact.observation_p30 FORCE ROW LEVEL SECURITY;
CREATE POLICY tenant_fence ON impact.observation_p30 USING (tenant_id = nullif(current_setting('impact.tenant_id',true),'')::uuid) WITH CHECK (tenant_id = nullif(current_setting('impact.tenant_id',true),'')::uuid);

ALTER TABLE impact.observation_p31 ENABLE ROW LEVEL SECURITY;
ALTER TABLE impact.observation_p31 FORCE ROW LEVEL SECURITY;
CREATE POLICY tenant_fence ON impact.observation_p31 USING (tenant_id = nullif(current_setting('impact.tenant_id',true),'')::uuid) WITH CHECK (tenant_id = nullif(current_setting('impact.tenant_id',true),'')::uuid);

ALTER TABLE impact.calculated_result_current ENABLE ROW LEVEL SECURITY;
ALTER TABLE impact.calculated_result_current FORCE ROW LEVEL SECURITY;
CREATE POLICY tenant_fence ON impact.calculated_result_current USING (tenant_id = nullif(current_setting('impact.tenant_id',true),'')::uuid) WITH CHECK (tenant_id = nullif(current_setting('impact.tenant_id',true),'')::uuid);

ALTER TABLE impact.form_current ENABLE ROW LEVEL SECURITY;
ALTER TABLE impact.form_current FORCE ROW LEVEL SECURITY;
CREATE POLICY tenant_fence ON impact.form_current USING (tenant_id = nullif(current_setting('impact.tenant_id',true),'')::uuid) WITH CHECK (tenant_id = nullif(current_setting('impact.tenant_id',true),'')::uuid);

ALTER TABLE impact.form_field_current ENABLE ROW LEVEL SECURITY;
ALTER TABLE impact.form_field_current FORCE ROW LEVEL SECURITY;
CREATE POLICY tenant_fence ON impact.form_field_current USING (tenant_id = nullif(current_setting('impact.tenant_id',true),'')::uuid) WITH CHECK (tenant_id = nullif(current_setting('impact.tenant_id',true),'')::uuid);

ALTER TABLE impact.assignment_current ENABLE ROW LEVEL SECURITY;
ALTER TABLE impact.assignment_current FORCE ROW LEVEL SECURITY;
CREATE POLICY tenant_fence ON impact.assignment_current USING (tenant_id = nullif(current_setting('impact.tenant_id',true),'')::uuid) WITH CHECK (tenant_id = nullif(current_setting('impact.tenant_id',true),'')::uuid);

ALTER TABLE impact.submission_current ENABLE ROW LEVEL SECURITY;
ALTER TABLE impact.submission_current FORCE ROW LEVEL SECURITY;
CREATE POLICY tenant_fence ON impact.submission_current USING (tenant_id = nullif(current_setting('impact.tenant_id',true),'')::uuid) WITH CHECK (tenant_id = nullif(current_setting('impact.tenant_id',true),'')::uuid);

ALTER TABLE impact.participant_current ENABLE ROW LEVEL SECURITY;
ALTER TABLE impact.participant_current FORCE ROW LEVEL SECURITY;
CREATE POLICY tenant_fence ON impact.participant_current USING (tenant_id = nullif(current_setting('impact.tenant_id',true),'')::uuid) WITH CHECK (tenant_id = nullif(current_setting('impact.tenant_id',true),'')::uuid);

ALTER TABLE impact.service_event_current ENABLE ROW LEVEL SECURITY;
ALTER TABLE impact.service_event_current FORCE ROW LEVEL SECURITY;
CREATE POLICY tenant_fence ON impact.service_event_current USING (tenant_id = nullif(current_setting('impact.tenant_id',true),'')::uuid) WITH CHECK (tenant_id = nullif(current_setting('impact.tenant_id',true),'')::uuid);

ALTER TABLE impact.handling_record_current ENABLE ROW LEVEL SECURITY;
ALTER TABLE impact.handling_record_current FORCE ROW LEVEL SECURITY;
CREATE POLICY tenant_fence ON impact.handling_record_current USING (tenant_id = nullif(current_setting('impact.tenant_id',true),'')::uuid) WITH CHECK (tenant_id = nullif(current_setting('impact.tenant_id',true),'')::uuid);

ALTER TABLE impact.dataset_current ENABLE ROW LEVEL SECURITY;
ALTER TABLE impact.dataset_current FORCE ROW LEVEL SECURITY;
CREATE POLICY tenant_fence ON impact.dataset_current USING (tenant_id = nullif(current_setting('impact.tenant_id',true),'')::uuid) WITH CHECK (tenant_id = nullif(current_setting('impact.tenant_id',true),'')::uuid);

ALTER TABLE impact.import_job_current ENABLE ROW LEVEL SECURITY;
ALTER TABLE impact.import_job_current FORCE ROW LEVEL SECURITY;
CREATE POLICY tenant_fence ON impact.import_job_current USING (tenant_id = nullif(current_setting('impact.tenant_id',true),'')::uuid) WITH CHECK (tenant_id = nullif(current_setting('impact.tenant_id',true),'')::uuid);

ALTER TABLE impact.quality_issue_current ENABLE ROW LEVEL SECURITY;
ALTER TABLE impact.quality_issue_current FORCE ROW LEVEL SECURITY;
CREATE POLICY tenant_fence ON impact.quality_issue_current USING (tenant_id = nullif(current_setting('impact.tenant_id',true),'')::uuid) WITH CHECK (tenant_id = nullif(current_setting('impact.tenant_id',true),'')::uuid);

ALTER TABLE impact.evidence_current ENABLE ROW LEVEL SECURITY;
ALTER TABLE impact.evidence_current FORCE ROW LEVEL SECURITY;
CREATE POLICY tenant_fence ON impact.evidence_current USING (tenant_id = nullif(current_setting('impact.tenant_id',true),'')::uuid) WITH CHECK (tenant_id = nullif(current_setting('impact.tenant_id',true),'')::uuid);

ALTER TABLE impact.workflow_current ENABLE ROW LEVEL SECURITY;
ALTER TABLE impact.workflow_current FORCE ROW LEVEL SECURITY;
CREATE POLICY tenant_fence ON impact.workflow_current USING (tenant_id = nullif(current_setting('impact.tenant_id',true),'')::uuid) WITH CHECK (tenant_id = nullif(current_setting('impact.tenant_id',true),'')::uuid);

ALTER TABLE impact.decision_current ENABLE ROW LEVEL SECURITY;
ALTER TABLE impact.decision_current FORCE ROW LEVEL SECURITY;
CREATE POLICY tenant_fence ON impact.decision_current USING (tenant_id = nullif(current_setting('impact.tenant_id',true),'')::uuid) WITH CHECK (tenant_id = nullif(current_setting('impact.tenant_id',true),'')::uuid);

ALTER TABLE impact.snapshot_current ENABLE ROW LEVEL SECURITY;
ALTER TABLE impact.snapshot_current FORCE ROW LEVEL SECURITY;
CREATE POLICY tenant_fence ON impact.snapshot_current USING (tenant_id = nullif(current_setting('impact.tenant_id',true),'')::uuid) WITH CHECK (tenant_id = nullif(current_setting('impact.tenant_id',true),'')::uuid);

ALTER TABLE impact.report_current ENABLE ROW LEVEL SECURITY;
ALTER TABLE impact.report_current FORCE ROW LEVEL SECURITY;
CREATE POLICY tenant_fence ON impact.report_current USING (tenant_id = nullif(current_setting('impact.tenant_id',true),'')::uuid) WITH CHECK (tenant_id = nullif(current_setting('impact.tenant_id',true),'')::uuid);

ALTER TABLE impact.disclosure_current ENABLE ROW LEVEL SECURITY;
ALTER TABLE impact.disclosure_current FORCE ROW LEVEL SECURITY;
CREATE POLICY tenant_fence ON impact.disclosure_current USING (tenant_id = nullif(current_setting('impact.tenant_id',true),'')::uuid) WITH CHECK (tenant_id = nullif(current_setting('impact.tenant_id',true),'')::uuid);

ALTER TABLE impact.budget_line_current ENABLE ROW LEVEL SECURITY;
ALTER TABLE impact.budget_line_current FORCE ROW LEVEL SECURITY;
CREATE POLICY tenant_fence ON impact.budget_line_current USING (tenant_id = nullif(current_setting('impact.tenant_id',true),'')::uuid) WITH CHECK (tenant_id = nullif(current_setting('impact.tenant_id',true),'')::uuid);

ALTER TABLE impact.connection_current ENABLE ROW LEVEL SECURITY;
ALTER TABLE impact.connection_current FORCE ROW LEVEL SECURITY;
CREATE POLICY tenant_fence ON impact.connection_current USING (tenant_id = nullif(current_setting('impact.tenant_id',true),'')::uuid) WITH CHECK (tenant_id = nullif(current_setting('impact.tenant_id',true),'')::uuid);

ALTER TABLE impact.a_i_task_current ENABLE ROW LEVEL SECURITY;
ALTER TABLE impact.a_i_task_current FORCE ROW LEVEL SECURITY;
CREATE POLICY tenant_fence ON impact.a_i_task_current USING (tenant_id = nullif(current_setting('impact.tenant_id',true),'')::uuid) WITH CHECK (tenant_id = nullif(current_setting('impact.tenant_id',true),'')::uuid);

ALTER TABLE impact.privacy_case_current ENABLE ROW LEVEL SECURITY;
ALTER TABLE impact.privacy_case_current FORCE ROW LEVEL SECURITY;
CREATE POLICY tenant_fence ON impact.privacy_case_current USING (tenant_id = nullif(current_setting('impact.tenant_id',true),'')::uuid) WITH CHECK (tenant_id = nullif(current_setting('impact.tenant_id',true),'')::uuid);

ALTER TABLE impact.audit_event_current ENABLE ROW LEVEL SECURITY;
ALTER TABLE impact.audit_event_current FORCE ROW LEVEL SECURITY;
CREATE POLICY tenant_fence ON impact.audit_event_current USING (tenant_id = nullif(current_setting('impact.tenant_id',true),'')::uuid) WITH CHECK (tenant_id = nullif(current_setting('impact.tenant_id',true),'')::uuid);

ALTER TABLE impact.evaluation_current ENABLE ROW LEVEL SECURITY;
ALTER TABLE impact.evaluation_current FORCE ROW LEVEL SECURITY;
CREATE POLICY tenant_fence ON impact.evaluation_current USING (tenant_id = nullif(current_setting('impact.tenant_id',true),'')::uuid) WITH CHECK (tenant_id = nullif(current_setting('impact.tenant_id',true),'')::uuid);

ALTER TABLE impact.retention_policy_current ENABLE ROW LEVEL SECURITY;
ALTER TABLE impact.retention_policy_current FORCE ROW LEVEL SECURITY;
CREATE POLICY tenant_fence ON impact.retention_policy_current USING (tenant_id = nullif(current_setting('impact.tenant_id',true),'')::uuid) WITH CHECK (tenant_id = nullif(current_setting('impact.tenant_id',true),'')::uuid);

ALTER TABLE impact.subscription_current ENABLE ROW LEVEL SECURITY;
ALTER TABLE impact.subscription_current FORCE ROW LEVEL SECURITY;
CREATE POLICY tenant_fence ON impact.subscription_current USING (tenant_id = nullif(current_setting('impact.tenant_id',true),'')::uuid) WITH CHECK (tenant_id = nullif(current_setting('impact.tenant_id',true),'')::uuid);

ALTER TABLE impact.funding_agreement_current ENABLE ROW LEVEL SECURITY;
ALTER TABLE impact.funding_agreement_current FORCE ROW LEVEL SECURITY;
CREATE POLICY tenant_fence ON impact.funding_agreement_current USING (tenant_id = nullif(current_setting('impact.tenant_id',true),'')::uuid) WITH CHECK (tenant_id = nullif(current_setting('impact.tenant_id',true),'')::uuid);

ALTER TABLE impact.finance_transaction_current ENABLE ROW LEVEL SECURITY;
ALTER TABLE impact.finance_transaction_current FORCE ROW LEVEL SECURITY;
CREATE POLICY tenant_fence ON impact.finance_transaction_current USING (tenant_id = nullif(current_setting('impact.tenant_id',true),'')::uuid) WITH CHECK (tenant_id = nullif(current_setting('impact.tenant_id',true),'')::uuid);

ALTER TABLE impact.exchange_rate_current ENABLE ROW LEVEL SECURITY;
ALTER TABLE impact.exchange_rate_current FORCE ROW LEVEL SECURITY;
CREATE POLICY tenant_fence ON impact.exchange_rate_current USING (tenant_id = nullif(current_setting('impact.tenant_id',true),'')::uuid) WITH CHECK (tenant_id = nullif(current_setting('impact.tenant_id',true),'')::uuid);

ALTER TABLE impact.allocation_rule_current ENABLE ROW LEVEL SECURITY;
ALTER TABLE impact.allocation_rule_current FORCE ROW LEVEL SECURITY;
CREATE POLICY tenant_fence ON impact.allocation_rule_current USING (tenant_id = nullif(current_setting('impact.tenant_id',true),'')::uuid) WITH CHECK (tenant_id = nullif(current_setting('impact.tenant_id',true),'')::uuid);

ALTER TABLE impact.work_item_current ENABLE ROW LEVEL SECURITY;
ALTER TABLE impact.work_item_current FORCE ROW LEVEL SECURITY;
CREATE POLICY tenant_fence ON impact.work_item_current USING (tenant_id = nullif(current_setting('impact.tenant_id',true),'')::uuid) WITH CHECK (tenant_id = nullif(current_setting('impact.tenant_id',true),'')::uuid);

ALTER TABLE impact.dashboard_current ENABLE ROW LEVEL SECURITY;
ALTER TABLE impact.dashboard_current FORCE ROW LEVEL SECURITY;
CREATE POLICY tenant_fence ON impact.dashboard_current USING (tenant_id = nullif(current_setting('impact.tenant_id',true),'')::uuid) WITH CHECK (tenant_id = nullif(current_setting('impact.tenant_id',true),'')::uuid);

ALTER TABLE impact.report_template_current ENABLE ROW LEVEL SECURITY;
ALTER TABLE impact.report_template_current FORCE ROW LEVEL SECURITY;
CREATE POLICY tenant_fence ON impact.report_template_current USING (tenant_id = nullif(current_setting('impact.tenant_id',true),'')::uuid) WITH CHECK (tenant_id = nullif(current_setting('impact.tenant_id',true),'')::uuid);

ALTER TABLE impact.notification_current ENABLE ROW LEVEL SECURITY;
ALTER TABLE impact.notification_current FORCE ROW LEVEL SECURITY;
CREATE POLICY tenant_fence ON impact.notification_current USING (tenant_id = nullif(current_setting('impact.tenant_id',true),'')::uuid) WITH CHECK (tenant_id = nullif(current_setting('impact.tenant_id',true),'')::uuid);

ALTER TABLE impact.schedule_current ENABLE ROW LEVEL SECURITY;
ALTER TABLE impact.schedule_current FORCE ROW LEVEL SECURITY;
CREATE POLICY tenant_fence ON impact.schedule_current USING (tenant_id = nullif(current_setting('impact.tenant_id',true),'')::uuid) WITH CHECK (tenant_id = nullif(current_setting('impact.tenant_id',true),'')::uuid);

ALTER TABLE impact.qualitative_extract_current ENABLE ROW LEVEL SECURITY;
ALTER TABLE impact.qualitative_extract_current FORCE ROW LEVEL SECURITY;
CREATE POLICY tenant_fence ON impact.qualitative_extract_current USING (tenant_id = nullif(current_setting('impact.tenant_id',true),'')::uuid) WITH CHECK (tenant_id = nullif(current_setting('impact.tenant_id',true),'')::uuid);

ALTER TABLE impact.device_current ENABLE ROW LEVEL SECURITY;
ALTER TABLE impact.device_current FORCE ROW LEVEL SECURITY;
CREATE POLICY tenant_fence ON impact.device_current USING (tenant_id = nullif(current_setting('impact.tenant_id',true),'')::uuid) WITH CHECK (tenant_id = nullif(current_setting('impact.tenant_id',true),'')::uuid);

ALTER TABLE impact.support_request_current ENABLE ROW LEVEL SECURITY;
ALTER TABLE impact.support_request_current FORCE ROW LEVEL SECURITY;
CREATE POLICY tenant_fence ON impact.support_request_current USING (tenant_id = nullif(current_setting('impact.tenant_id',true),'')::uuid) WITH CHECK (tenant_id = nullif(current_setting('impact.tenant_id',true),'')::uuid);

ALTER TABLE impact.access_epoch ENABLE ROW LEVEL SECURITY;
ALTER TABLE impact.access_epoch FORCE ROW LEVEL SECURITY;
CREATE POLICY tenant_fence ON impact.access_epoch USING (tenant_id = nullif(current_setting('impact.tenant_id',true),'')::uuid) WITH CHECK (tenant_id = nullif(current_setting('impact.tenant_id',true),'')::uuid);

ALTER TABLE impact.operation_receipt ENABLE ROW LEVEL SECURITY;
ALTER TABLE impact.operation_receipt FORCE ROW LEVEL SECURITY;
CREATE POLICY tenant_fence ON impact.operation_receipt USING (tenant_id = nullif(current_setting('impact.tenant_id',true),'')::uuid) WITH CHECK (tenant_id = nullif(current_setting('impact.tenant_id',true),'')::uuid);

ALTER TABLE impact.source_key_registry ENABLE ROW LEVEL SECURITY;
ALTER TABLE impact.source_key_registry FORCE ROW LEVEL SECURITY;
CREATE POLICY tenant_fence ON impact.source_key_registry USING (tenant_id = nullif(current_setting('impact.tenant_id',true),'')::uuid) WITH CHECK (tenant_id = nullif(current_setting('impact.tenant_id',true),'')::uuid);

ALTER TABLE impact.source_revision_receipt ENABLE ROW LEVEL SECURITY;
ALTER TABLE impact.source_revision_receipt FORCE ROW LEVEL SECURITY;
CREATE POLICY tenant_fence ON impact.source_revision_receipt USING (tenant_id = nullif(current_setting('impact.tenant_id',true),'')::uuid) WITH CHECK (tenant_id = nullif(current_setting('impact.tenant_id',true),'')::uuid);

ALTER TABLE impact.workflow_author ENABLE ROW LEVEL SECURITY;
ALTER TABLE impact.workflow_author FORCE ROW LEVEL SECURITY;
CREATE POLICY tenant_fence ON impact.workflow_author USING (tenant_id = nullif(current_setting('impact.tenant_id',true),'')::uuid) WITH CHECK (tenant_id = nullif(current_setting('impact.tenant_id',true),'')::uuid);

ALTER TABLE impact.review_decision ENABLE ROW LEVEL SECURITY;
ALTER TABLE impact.review_decision FORCE ROW LEVEL SECURITY;
CREATE POLICY tenant_fence ON impact.review_decision USING (tenant_id = nullif(current_setting('impact.tenant_id',true),'')::uuid) WITH CHECK (tenant_id = nullif(current_setting('impact.tenant_id',true),'')::uuid);

ALTER TABLE impact.lineage_edge ENABLE ROW LEVEL SECURITY;
ALTER TABLE impact.lineage_edge FORCE ROW LEVEL SECURITY;
CREATE POLICY tenant_fence ON impact.lineage_edge USING (tenant_id = nullif(current_setting('impact.tenant_id',true),'')::uuid) WITH CHECK (tenant_id = nullif(current_setting('impact.tenant_id',true),'')::uuid);

ALTER TABLE impact.snapshot_member ENABLE ROW LEVEL SECURITY;
ALTER TABLE impact.snapshot_member FORCE ROW LEVEL SECURITY;
CREATE POLICY tenant_fence ON impact.snapshot_member USING (tenant_id = nullif(current_setting('impact.tenant_id',true),'')::uuid) WITH CHECK (tenant_id = nullif(current_setting('impact.tenant_id',true),'')::uuid);

ALTER TABLE impact.file_blob ENABLE ROW LEVEL SECURITY;
ALTER TABLE impact.file_blob FORCE ROW LEVEL SECURITY;
CREATE POLICY tenant_fence ON impact.file_blob USING (tenant_id = nullif(current_setting('impact.tenant_id',true),'')::uuid) WITH CHECK (tenant_id = nullif(current_setting('impact.tenant_id',true),'')::uuid);

ALTER TABLE impact.offline_grant ENABLE ROW LEVEL SECURITY;
ALTER TABLE impact.offline_grant FORCE ROW LEVEL SECURITY;
CREATE POLICY tenant_fence ON impact.offline_grant USING (tenant_id = nullif(current_setting('impact.tenant_id',true),'')::uuid) WITH CHECK (tenant_id = nullif(current_setting('impact.tenant_id',true),'')::uuid);

ALTER TABLE impact.sync_receipt ENABLE ROW LEVEL SECURITY;
ALTER TABLE impact.sync_receipt FORCE ROW LEVEL SECURITY;
CREATE POLICY tenant_fence ON impact.sync_receipt USING (tenant_id = nullif(current_setting('impact.tenant_id',true),'')::uuid) WITH CHECK (tenant_id = nullif(current_setting('impact.tenant_id',true),'')::uuid);

ALTER TABLE impact.job ENABLE ROW LEVEL SECURITY;
ALTER TABLE impact.job FORCE ROW LEVEL SECURITY;
CREATE POLICY tenant_fence ON impact.job USING (tenant_id = nullif(current_setting('impact.tenant_id',true),'')::uuid) WITH CHECK (tenant_id = nullif(current_setting('impact.tenant_id',true),'')::uuid);

ALTER TABLE impact.job_item ENABLE ROW LEVEL SECURITY;
ALTER TABLE impact.job_item FORCE ROW LEVEL SECURITY;
CREATE POLICY tenant_fence ON impact.job_item USING (tenant_id = nullif(current_setting('impact.tenant_id',true),'')::uuid) WITH CHECK (tenant_id = nullif(current_setting('impact.tenant_id',true),'')::uuid);

ALTER TABLE impact.outbox_event ENABLE ROW LEVEL SECURITY;
ALTER TABLE impact.outbox_event FORCE ROW LEVEL SECURITY;
CREATE POLICY tenant_fence ON impact.outbox_event USING (tenant_id = nullif(current_setting('impact.tenant_id',true),'')::uuid) WITH CHECK (tenant_id = nullif(current_setting('impact.tenant_id',true),'')::uuid);

ALTER TABLE impact.consumer_receipt ENABLE ROW LEVEL SECURITY;
ALTER TABLE impact.consumer_receipt FORCE ROW LEVEL SECURITY;
CREATE POLICY tenant_fence ON impact.consumer_receipt USING (tenant_id = nullif(current_setting('impact.tenant_id',true),'')::uuid) WITH CHECK (tenant_id = nullif(current_setting('impact.tenant_id',true),'')::uuid);

ALTER TABLE impact.deletion_ledger ENABLE ROW LEVEL SECURITY;
ALTER TABLE impact.deletion_ledger FORCE ROW LEVEL SECURITY;
CREATE POLICY tenant_fence ON impact.deletion_ledger USING (tenant_id = nullif(current_setting('impact.tenant_id',true),'')::uuid) WITH CHECK (tenant_id = nullif(current_setting('impact.tenant_id',true),'')::uuid);

ALTER TABLE impact.retention_hold ENABLE ROW LEVEL SECURITY;
ALTER TABLE impact.retention_hold FORCE ROW LEVEL SECURITY;
CREATE POLICY tenant_fence ON impact.retention_hold USING (tenant_id = nullif(current_setting('impact.tenant_id',true),'')::uuid) WITH CHECK (tenant_id = nullif(current_setting('impact.tenant_id',true),'')::uuid);

ALTER TABLE impact.webhook_delivery ENABLE ROW LEVEL SECURITY;
ALTER TABLE impact.webhook_delivery FORCE ROW LEVEL SECURITY;
CREATE POLICY tenant_fence ON impact.webhook_delivery USING (tenant_id = nullif(current_setting('impact.tenant_id',true),'')::uuid) WITH CHECK (tenant_id = nullif(current_setting('impact.tenant_id',true),'')::uuid);

ALTER TABLE impact.audit_batch_root ENABLE ROW LEVEL SECURITY;
ALTER TABLE impact.audit_batch_root FORCE ROW LEVEL SECURITY;
CREATE POLICY tenant_fence ON impact.audit_batch_root USING (tenant_id = nullif(current_setting('impact.tenant_id',true),'')::uuid) WITH CHECK (tenant_id = nullif(current_setting('impact.tenant_id',true),'')::uuid);

ALTER TABLE impact.application_session ENABLE ROW LEVEL SECURITY;
ALTER TABLE impact.application_session FORCE ROW LEVEL SECURITY;
CREATE POLICY tenant_fence ON impact.application_session USING (tenant_id = nullif(current_setting('impact.tenant_id',true),'')::uuid) WITH CHECK (tenant_id = nullif(current_setting('impact.tenant_id',true),'')::uuid);

ALTER TABLE impact.member_invitation ENABLE ROW LEVEL SECURITY;
ALTER TABLE impact.member_invitation FORCE ROW LEVEL SECURITY;
CREATE POLICY tenant_fence ON impact.member_invitation USING (tenant_id = nullif(current_setting('impact.tenant_id',true),'')::uuid) WITH CHECK (tenant_id = nullif(current_setting('impact.tenant_id',true),'')::uuid);

ALTER TABLE impact.scope_definition ENABLE ROW LEVEL SECURITY;
ALTER TABLE impact.scope_definition FORCE ROW LEVEL SECURITY;
CREATE POLICY tenant_fence ON impact.scope_definition USING (tenant_id = nullif(current_setting('impact.tenant_id',true),'')::uuid) WITH CHECK (tenant_id = nullif(current_setting('impact.tenant_id',true),'')::uuid);

ALTER TABLE impact.scope_member ENABLE ROW LEVEL SECURITY;
ALTER TABLE impact.scope_member FORCE ROW LEVEL SECURITY;
CREATE POLICY tenant_fence ON impact.scope_member USING (tenant_id = nullif(current_setting('impact.tenant_id',true),'')::uuid) WITH CHECK (tenant_id = nullif(current_setting('impact.tenant_id',true),'')::uuid);

ALTER TABLE impact.service_identity ENABLE ROW LEVEL SECURITY;
ALTER TABLE impact.service_identity FORCE ROW LEVEL SECURITY;
CREATE POLICY tenant_fence ON impact.service_identity USING (tenant_id = nullif(current_setting('impact.tenant_id',true),'')::uuid) WITH CHECK (tenant_id = nullif(current_setting('impact.tenant_id',true),'')::uuid);

ALTER TABLE impact.upload_session ENABLE ROW LEVEL SECURITY;
ALTER TABLE impact.upload_session FORCE ROW LEVEL SECURITY;
CREATE POLICY tenant_fence ON impact.upload_session USING (tenant_id = nullif(current_setting('impact.tenant_id',true),'')::uuid) WITH CHECK (tenant_id = nullif(current_setting('impact.tenant_id',true),'')::uuid);

CREATE INDEX observation_by_indicator_period ON impact.observation_current(tenant_id,indicator_id,event_at,object_id);

CREATE INDEX revision_by_object ON impact.object_revision(tenant_id,object_id,created_at DESC);

CREATE INDEX queued_jobs ON impact.job(tenant_id,job_class,state,job_id);

CREATE INDEX pending_outbox ON impact.outbox_event(occurred_at,event_id) WHERE sent_at IS NULL;

-- Append-only revision/audit and privacy-executor privileges require separate qualified deployment roles.

-- DRAFT nullable columns are intentional. Activation validates required fields from entity-catalogue.json.

-- JSON payloads require typed DTO validation; this file is not the complete deployable migration.