# Architecture diagrams

```mermaid
flowchart TD
  Web[Web application] --> API[Authenticated domain core]
  Android[Android field client] --> API
  Service[Scoped integrations] --> API
  API --> DB[PostgreSQL revisions and receipts]
  API --> Files[Private quarantine and artifacts]
  DB --> Outbox[Outbox dispatcher]
  Outbox --> Queue[At least once queue]
  Queue --> Workers[Isolated worker pools]
  Workers --> DB
  Workers --> Files
  Workers --> Providers[Approved external providers]
```

```mermaid
sequenceDiagram
  participant C as Client
  participant A as API and policy
  participant D as Database
  participant W as Worker
  C->>A: Command with operation and revision
  A->>D: Lock policy receipt and object head
  A->>D: Commit revision audit receipt outbox
  D-->>A: Durable commit
  A-->>C: Business receipt
  D-->>W: Outbox event through queue
  W->>D: Current authority and fenced lease
  W->>D: Commit item effect and receipt
  C->>A: Query job and outcome
  A-->>C: Current authorised result
```

The sequence omits queue mechanics to keep the transactional relationship legible. Delivery can duplicate or reorder; durable domain identity and fencing govern effects.
