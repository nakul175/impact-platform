# API fixture provisioning contract

Create two isolated synthetic tenants, A and B, with distinctive marker values in rows, files, search and AI content. Use the release's real identity provider and authorisation implementation. Record exact build, schema, policy and seed digest. Do not disable authorisation to simplify the test.

| Fixture field | Required state |
| --- | --- |
| tenant_a and tenant_b | Different active tenants with approved activation policies. |
| programme_a | Active or readable programme in A, visible to A author. |
| programme_b | Programme in B; A author has no membership or grant in B. |
| mutable_programme | Dedicated draft in A; author may edit its title. No other test may change it concurrently. |
| report_a | Approved report metadata in A. Revoked principal formerly had access but current revocation is effective. |
| pooled_result | Official CAL01 result: 51/110 percent, stored 46.363636363636, displayed 46.36, PRESENT with lineage. |
| connection_a | Admin-readable connection metadata with safe credential reference, never raw secret values. |
| own_workflow | Active review workflow whose exact candidate was authored by the author principal. |
| workflow_revision | Current workflow revision; refresh after provisioning. |
| candidate_revision | Exact candidate bound to own_workflow. |
| evidence_a | Permitted clean evidence metadata; this harness does not download content. |
| form_a | Permitted published form metadata. |
| expired_sync_payload | Otherwise valid submission, assignment, form and device grant bound to enumerator; grant expired under server clock. |

The author has programme read/edit, relevant result/evidence/form read and workflow review capability but is forbidden to approve their own candidate. The reviewer is a different verified natural person. The partner cannot list global tenant membership. The admin can inspect connection metadata. The enumerator is correctly bound to the expired offline grant. The revoked principal's token may remain cryptographically valid so the test proves domain revocation rather than mere token parsing.

Provide valid server tokens through environment variables only. `actors.<role>.token_env` contains the variable name, not the token. The base URL must use HTTPS except on loopback. API redirects are intentionally rejected. All responses use the proposed API envelope and semantic error contract; if the implementation chooses a different transport, adapt the client mapping without weakening expected domain outcomes.

The runtime manifest contains environment, build_id, schema_version, fixture_id and mutation_tests_allowed. Only a fixture with all three opt ins can run write tests. A failed cleanup leaves the fixture quarantined for inspection. Delete the entire isolated test tenant through a governed cleanup process when the qualification run is complete; do not remove audit rows selectively.
