// Optional browser qualification smoke. Requires Playwright and installed Chromium.
import {chromium} from 'playwright';
import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import path from 'node:path';
import {fileURLToPath,pathToFileURL} from 'node:url';
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
let browser;
try {browser=await chromium.launch({headless:true});}
catch(error){await fs.mkdir(path.join(root,'reports'),{recursive:true});await fs.writeFile(path.join(root,'reports/prototype-browser.json'),JSON.stringify({status:'Blocked',reason:'A Playwright Chromium executable is not available in this preparation environment',product_validated:false},null,2));console.error('Blocked: Chromium executable unavailable');process.exit(3);}
const page=await browser.newPage({viewport:{width:1440,height:1000}});const errors=[];page.on('pageerror',e=>errors.push(e.message));
try{
 await page.goto(pathToFileURL(path.join(root,'wireframes.html')).href);
 assert.equal(await page.locator('[data-screen]').count(),30);
 for(let i=1;i<=30;i++){const id='UI'+String(i).padStart(2,'0');await page.locator(`[data-screen="${id}"]`).click();assert(await page.locator('h1').textContent());}
 await page.setViewportSize({width:390,height:844});await page.evaluate(()=>window.impactPrototype.navigate('UI13'));
 assert(await page.evaluate(()=>document.documentElement.scrollWidth<=window.innerWidth));
 await page.locator('[data-action="Save on device"]').click();await page.evaluate(()=>window.impactPrototype.navigate('UI14'));await page.locator('[data-action="Sync now"]').click();await page.evaluate(()=>window.impactPrototype.navigate('UI21'));
 await page.locator('[data-action="Approve candidate"]').click();assert.equal(await page.locator('dialog[open]').count(),0);
 await page.selectOption('#role','Riya');await page.locator('[data-action="Approve candidate"]').click();await page.locator('#confirm-dialog').click();
 await page.evaluate(()=>window.impactPrototype.navigate('UI24'));await page.locator('[data-action="Close period"]').click();assert.equal(await page.locator('dialog[open]').count(),0);await page.locator('[data-action="Load complete-period example"]').click();await page.locator('[data-action="Close period"]').click();await page.locator('#confirm-dialog').click();
 assert.equal(await page.evaluate(()=>window.impactPrototype.state.closed),true);assert.deepEqual(errors,[]);
 await page.screenshot({path:path.join(root,'reports/prototype-mobile.png'),fullPage:true});
 await fs.writeFile(path.join(root,'reports/prototype-browser.json'),JSON.stringify({status:'Pass',screens:30,mobile_width:390,script_errors:errors,product_validated:false,scope:'Prototype browser smoke only; not WCAG or application qualification'},null,2));
}finally{await browser.close();}
